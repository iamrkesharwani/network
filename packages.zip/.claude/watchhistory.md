# Watch History & Resume Playback — Implementation Plan

## 0. Decisions locked in

- Covers **both** `video` and `short` content (polymorphic entries).
- Ships with **full management**: list, delete one entry, clear all.
- **Absorbs** `telemetry.WatchProgress` — that model/service/routes/flush-worker are retired and their job is taken over by the new `history` module. `telemetry` module is deleted entirely (it had no other responsibility).
- **Every progress ping counts** — no minimum-watch-time floor. Even a 1-2 second ping creates/updates a history row.
- **No content purge** — a history entry is never deleted just because the underlying video/short was removed or changed visibility. Unlisted content stays visible in the watcher's own history.

---

## 1. Plain-English problem & flow

There are two gaps today: no resume-from-last-position, and no browsable/manageable Watch History list. The player already pings the server every few seconds with playback position, but nothing reads it back, and it only covers videos. Flow once built:

1. Player pings server every few seconds: "user X is at time T in content Y."
2. Server buffers that in Redis (fast, avoids hammering Mongo on every tick).
3. Every 5 minutes, a flush job sweeps Redis and upserts each entry into `WatchHistory` in Mongo (rewatching bumps it back to the top of the list).
4. On opening content again, the app asks "is there a saved position for this?" — if yes, the player seeks there. That's resume.
5. The app can list "most recently watched" for a history page.
6. The user can delete one entry or clear everything.

---

## 2. Why absorb WatchProgress instead of running two systems

|            | Today (`telemetry.WatchProgress`)                                                  | New (`history`)                                               |
| ---------- | ---------------------------------------------------------------------------------- | ------------------------------------------------------------- |
| Scope      | video only (`videoId` field)                                                       | video **or** short (`contentType` + `contentId`)              |
| Write path | `POST /telemetry/progress` → Redis (7d TTL) → BullMQ flush every 5m → Mongo upsert | same Redis+BullMQ pattern, repointed at `HistoryModel`        |
| Read path  | **none**                                                                           | `GET /history`, `GET /history/:contentType/:contentId/resume` |
| Collection | `WatchProgress` (userId+videoId unique)                                            | `WatchHistory` (userId+contentType+contentId unique)          |

Keeping both would mean two collections answering "where did this user leave off," which will drift. The Redis-buffer → BullMQ-flush design is solid (avoids hammering Mongo on every timeupdate tick) and gets reused as-is, just renamed and pointed at the new model.

---

## 3. Data model — `WatchHistory`

```
userId        ObjectId  ref User        required
contentType   'video' | 'short'         required
contentId     ObjectId  refPath by contentType ('Video' | 'Short')   required
currentTime   Number (seconds)          required, min 0
duration      Number (seconds)          optional — snapshot at last ping, powers % progress in the list UI
createdAt     Date   (= first watched)
updatedAt     Date   (= last watched — this is what "recency" sorts on)
```

- Unique compound index: `{ userId: 1, contentType: 1, contentId: 1 }` — one row per (user, content), upserted on **every** progress ping (no threshold gate). Re-watching bumps `updatedAt` and moves it to the top of history, same as YouTube/Netflix.
- Index `{ userId: 1, updatedAt: -1 }` to drive the paginated list.
- `completed` is **derived**, not stored: `currentTime / duration >= 0.95`. Computed at read time in the mapper — avoids a second write path getting out of sync.

**Pagination note:** the codebase's shared `paginateQuery()` util sorts by `_id` descending, which works for "created order" feeds (video/short feeds) but is wrong here — a rewatched item must jump to the top even though its `_id` is old. So the history repository needs its **own** cursor function sorted by `(updatedAt, _id)` instead of reusing `paginateQuery`. This is the one deliberate deviation from the standard module pattern, called out explicitly so it isn't "fixed" back to the shared util later.

**No purge policy:** the list query does **not** filter by content visibility or deletion state beyond what's needed to avoid a hard crash. If a video/short is soft-deleted or made unlisted, its history entry stays exactly as-is and keeps showing in the watcher's history. The mapper only needs defensive handling for the rare case where `contentId` no longer resolves at all (hard-deleted) — skip that single entry in the response rather than failing the whole page — but it does **not** delete the orphaned row or otherwise treat it as something to clean up.

---

## 4. Files to create

### `packages/shared/src`

- `constants/history.constants.ts` — `HISTORY_CONTENT_TYPES = ['video','short']`, `HISTORY_COMPLETED_THRESHOLD = 0.95`
- `types/history.types.ts` — `IHistory`, `IHistoryResponse`, `HistoryProgressInput`, `HistoryFeedQuery`
- `schemas/history.schema.ts` — `historyProgressSchema`, `historyContentParamSchema` (contentType enum + contentId), `historyIdParamSchema`, `historyFeedQuerySchema`
- export all of the above from `index.ts`

### `packages/server/src/modules/history/`

- `history.model.ts` — schema above, with `refPath`-style dynamic ref mapped to `Video`/`Short` (`'video' → 'Video'`, `'short' → 'Short'`)
- `history.repository.ts`
  - `upsertProgress(userId, contentType, contentId, currentTime, duration?)` — unconditional upsert, no gating
  - `findByUserPaginated(userId, cursor, limit)` — custom `updatedAt`-based cursor (see §3)
  - `findByUserAndContent(userId, contentType, contentId)` — for the resume lookup
  - `deleteById(id)`, `deleteAllByUserId(userId)`
- `history.types.ts` — `Requester`, `UpsertHistoryData`
- `services/history.progress.service.ts` — Redis-buffered write path (moved from `telemetry.service.ts`), now takes `contentType`; flush job upserts every buffered entry unconditionally, no threshold check
- `services/history.crud.service.ts` — `getHistory`, `getResumePoint`, `removeEntry` (ownership check), `clearHistory`
- `services/history.mappers.ts` — maps a populated doc → `IHistoryResponse` (title/thumbnail/duration pulled from the populated content, plus `currentTime`, `progressPercent`, `completed`, `lastWatchedAt`); skips a row only if `contentId` fails to resolve at all
- `history.flush.queue.ts` / `history.flush.worker.ts` — same BullMQ pattern as today, renamed, calling the new flush function
- `controllers/history.controller.ts` — `recordProgress`, `list`, `getResume`, `remove`, `clear`
- `controllers/params.ts` — `getContentTypeParam`, `getContentIdParam`, `getHistoryIdParam`
- `history.routes.ts`

### Wiring

- `route.ts` — add `router.use('/history', historyRoutes)`, remove the telemetry line
- `web.ts` — swap `startTelemetryFlushWorker`/`scheduleTelemetryFlush` imports for the `history` equivalents
- **Delete** `packages/server/src/modules/telemetry/` entirely

---

## 5. Routes

| Method | Path                                      | Auth     | Purpose                                                                                                             |
| ------ | ----------------------------------------- | -------- | ------------------------------------------------------------------------------------------------------------------- |
| POST   | `/history/progress`                       | required | Upsert a progress ping `{ contentType, contentId, currentTime, duration? }` — replaces `POST /telemetry/progress`   |
| GET    | `/history`                                | required | Paginated list, most-recently-watched first, populated with content summary                                         |
| GET    | `/history/:contentType/:contentId/resume` | required | **Resume playback** — returns `{ currentTime, duration, completed }` or `null` if never watched / already completed |
| DELETE | `/history/:id`                            | required | Remove one entry (ownership-checked)                                                                                |
| DELETE | `/history`                                | required | Clear all of the current user's history                                                                             |

`getResume` deliberately returns nothing resumable when `completed` is true, so a fully-watched video restarts from 0 instead of the end.

---

## 6. Client-side touch points (small, follow-on — not part of the 5 server files, flagging so it isn't forgotten)

- `useTelemetry.ts` → rename/generalize to accept `contentType`, point at `POST /history/progress`, and reuse for both `VideoPlayer.tsx` and `ShortFeed.tsx` (today it's wired to `VideoPlayer` only).
- New small hook (e.g. `useResumePlayback`) that calls `GET /history/:contentType/:contentId/resume` on mount and seeks the player to `currentTime` if resumable.
- A History page/list view is a separate UI task — out of scope unless you want it now.

---

## 7. Build order

1. Shared constants/types/schemas
2. `history.model.ts` + `history.repository.ts` (incl. the custom recency cursor)
3. `services/history.progress.service.ts` (Redis buffer) + flush queue/worker
4. `services/history.crud.service.ts` + mappers
5. Controllers + `params.ts` + `history.routes.ts`
6. Wire into `route.ts` / `web.ts`, delete `telemetry` module
7. (Follow-on) client hook updates

---

## 8. Assumptions

- `duration` is a snapshot on the row, not re-synced if the underlying video's duration changes.
- No cascade/purge behavior of any kind on video/short deletion or visibility change — history is an immutable log of what was watched, not a live view of current content state. The only defensive handling is skipping a single entry in the response if `contentId` fails to resolve at all, so one broken row can't take down the whole history page.

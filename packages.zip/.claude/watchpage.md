# Watch Page — Full Plan

## Layout

The page drops the current centered `max-w-4xl` column and spans full width, matching the feed. Top to bottom: video player, title, avatar/username/likes/views row, expandable description (truncated by default, click to expand), then a suggestions grid.

## Player

The player fills its container edge to edge in every state — loading, playing, paused, ended — with no padding or margin gap around it. The loading skeleton occupies the same box the loaded player will use, so there's no resize or jump when the video becomes ready.

Theater mode is removed entirely: no toggle, no fullscreen-backdrop portal, no Escape-key listener. The player becomes a plain fixed-aspect box.

Once a video finishes playing, an "Up Next" rail docks to the bottom of the player as a horizontal scrollable strip over a gradient scrim, readable against the paused final frame. Because the rail is an overlay inside the player's own bounds, it inherits the flush/no-padding treatment too — no gap between rail and player edges. Scrubbing back into the video hides the rail again.

The rail shows up to 10 compact cards (thumbnail, duration, truncated title, channel). If more related videos exist, an 11th card reads "Show more videos" and smooth-scrolls the page down to the suggestions grid rather than cramming more into the rail. Clicking a rail card is a full navigation to that video's watch page — not an in-place swap — so autoplay, captions, and telemetry reinitialize cleanly and the back button behaves normally.

The player progress bar doesn't fill out fully when the video ends. There is a small gray left out in the end that needs a fix to fully fill when the video ends.

In the settings, we need a "Lock" that will disable all the controls once enabled and a simple hover show up button within the video that will allow the user to unlock the control button. Additionally, the captions button is relatively smaller than the "Playback speed" button, we need a fix on that too to provide all the buttons equal size exactly. And Playback shouldn't say "Normal" it should just say 1x so that no user should feel they are abnormal.

The important one, the player is completely for the dark mode right now. We need to add a light mode sync to the overall app selection.

## Suggestions grid

Lives below the description, infinite-scroll rather than a fixed batch — reusing the same grid component and loading affordances already used on the main feed. The first page of related videos feeds both the rail (its first 10 items) and the top of this grid; scrolling further loads additional pages independently.

## Related-videos data

First page is a relevance-scored set (category match, tag overlap, weighted by recency/views/likes), backed by an additive index so it doesn't force a collection scan. If there aren't enough scored matches, it backfills with trending/recent content. Every page after the first switches to plain recency-based pagination, the same pattern the feed already uses — so pagination logic stays simple past page one. A small chance of an item repeating across that page-one/page-two boundary is treated as acceptable and deduplicated client-side rather than solved server-side.

## Edge cases

- Under 10 related videos: rail shows what's available, no "show more" card.
- Zero related videos: rail doesn't render, grid falls back to the existing empty state.
- Logged-out viewers still get suggestions, same as anonymous video viewing today.

## Supporting pieces

- Loading skeleton for the title/avatar/description block, sized to avoid layout shift once content loads.
- Avatar switches to the existing shared avatar component instead of a raw image tag.
- Mobile keeps the existing behavior of hiding the app sidebar.

## Suggested build order

1. Related-videos endpoint and pagination logic
2. Client data layer for the paginated query
3. Theater mode removal (isolated, no dependencies on the rest)
4. Expandable description
5. Up Next card and rail components
6. Player wiring for end-of-playback rail visibility, built flush/no-padding from the start
7. Full watch page layout and data wiring

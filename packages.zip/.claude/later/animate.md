# Motion Design Checklist — "Premium & Energetic" Pass

**Goal:** Every interaction should make the user think _"oh, this is a premium app"_ — not "cheap SaaS template." Motion personality: **energetic, confident, bouncy** (TikTok/Instagram Reels-grade), never gimmicky. **No hover-scale on buttons/cards** — that's an explicit anti-pattern for this pass; use tap feedback, elevation, layout motion, and shared-element transitions instead.

This doc was written after reading the actual codebase (`@network/client` — React 19, Redux Toolkit, Tailwind v4, Vite, `framer-motion` already installed, `canvas-confetti` already installed). File paths below are real and exact. Items marked **[REFERENCE QUALITY]** already exist in the codebase and should be used as the bar to match — don't reinvent their pattern, replicate it.

---

## 0. Before touching any component

### 0.1 Install two new dependencies

```bash
npm install vaul lenis
```

- **`vaul`** — native-feeling bottom sheets with drag-to-dismiss and snap points. Use for mobile modals instead of a centered dialog that's just smaller.
- **`lenis`** — momentum/inertia scrolling. Applied once to the main scroll container, it makes the _entire app_ feel more expensive without touching individual components.

Do **not** add anything else unless a specific checklist item below can't be done cleanly with `framer-motion` + Tailwind. `framer-motion` (already in `package.json`) covers ~95% of this list.

### 0.2 Create a shared motion primitives file

Create `packages/client/src/shared/motion/springs.ts`:

```ts
// Central spring vocabulary — every animated component should import from here,
// not invent its own stiffness/damping numbers. This is what makes 40 different
// components feel like ONE coherent motion language instead of scattered guesses.

export const springs = {
  // Taps, toggles, selections — fast, decisive, "snap to place"
  snappy: { type: 'spring', stiffness: 420, damping: 30, mass: 0.9 },

  // Entrances, celebrations, badge unlocks — the "TikTok bounce"
  bouncy: { type: 'spring', stiffness: 260, damping: 18, mass: 1 },

  // Layout reflow, grid column changes, sidebar width — controlled, no overshoot
  smooth: { type: 'spring', stiffness: 220, damping: 30, mass: 1 },

  // Shared-element / theater mode expansion — deliberate, cinematic
  cinematic: { type: 'spring', stiffness: 200, damping: 26, mass: 1.1 },
} as const;

export const durations = {
  micro: 0.12, // icon swaps, tiny state flips
  fast: 0.18, // toasts, dropdowns, tooltips
  base: 0.25, // modals, route transitions
  slow: 0.4, // page-level, celebratory sequences
} as const;

// Stagger presets for lists/grids
export const stagger = {
  tight: 0.03,
  relaxed: 0.06,
} as const;
```

Create `packages/client/src/shared/motion/useReducedMotionSafe.ts`:

```ts
import { useReducedMotion } from 'framer-motion';

// Wrap any spring/duration with this so `prefers-reduced-motion` is respected
// automatically everywhere, instead of every component remembering to check.
export const useMotionSafe = () => {
  const reduce = useReducedMotion();
  return {
    reduce,
    spring: (preset: object) => (reduce ? { duration: 0 } : preset),
  };
};
```

**Acceptance criteria:** No component below should define its own raw `{ stiffness, damping }` object — it imports from `springs.ts`. Exception: one-off celebratory sequences (`SuccessStep`, `BadgeToast`) may keep custom values since they're already reference-quality — but consider migrating them to named presets too (e.g. add a `celebratory` preset matching their current `stiffness: 260, damping: 20`) for consistency.

### 0.3 Reference-quality components already in the codebase — study these first

Before writing new motion code, read these three files. They are the existing quality bar; match their polish level everywhere else:

- `packages/client/src/features/upload/components/SuccessStep.tsx` — layered radiating pulse rings + spring-pop icon + staggered text reveal. This is your gold standard for "celebratory moment."
- `packages/client/src/features/upload/components/TagInput.tsx` — `AnimatePresence` + `layout` on a dynamic chip list. Gold standard for "items entering/leaving a flex-wrap container."
- `packages/client/src/features/upload/components/CategoryPicker.tsx` — `whileTap={{ scale: 0.94 }}` + icon pulse on selection. Gold standard for "selectable grid item" (note: this uses a _tap_ scale, not hover — consistent with the no-hover-scale rule).
- `packages/client/src/features/creator/components/BadgeToast.tsx` — spring entrance/exit toast. Gold standard for notification-style overlays.

---

## 1. Route & Page Transitions — Contextual, Not Generic

**Revision note:** the original version of this section (wrap `<Outlet />` in one blanket `AnimatePresence` fade+slide, applied identically to every route change) was implemented and correctly rejected — it animated the entire page including persistent chrome that never should have moved, produced a visible blank gap between pages, and looked identical regardless of what the user actually navigated to. That's the single most-cloned Framer Motion tutorial pattern on the internet, which is exactly why it read as generic/cheap rather than premium. Replaced below with a scheme that treats different route relationships differently, matching how native tab-based apps actually behave (most navigation is instant; motion is spent only where it's contextually earned).

**Files:** `packages/client/src/app/routes/AppRoutes.tsx`, `packages/client/src/app/layout/PageWrapper.tsx`, `packages/client/src/features/profile/components/ProfileTabContent.tsx`, `packages/client/src/features/upload/components/UploadHub.tsx`

Confirmed from `AppRoutes.tsx`: every route in the authenticated app (`Feed`, `Posts`, `Profile` + its 4 sub-tab routes, `Settings`, `Upload*`) sits under one shared `PageWrapper`. These routes are not all the same _kind_ of navigation, and shouldn't be animated as if they were:

### 1a. True siblings — Feed, Posts, Profile, Settings — no page-level transition at all

- [ ] **Remove the idea of wrapping `<Outlet />` in `AnimatePresence` entirely for these routes.** Content swaps immediately when moving between top-level nav items. The navbar/sidebar were already fixed and don't need to "settle" on every click — leave them alone.
- [ ] The sense of "aliveness" on arrival comes from what's _inside_ the page, not the page container itself — this is exactly what §2 (Feed & Grids stagger) and §10 (skeleton→content handoff) already cover. Those fire regardless of this section; no extra work needed here beyond _not_ adding a wrapper animation.
- [ ] **Feels premium when:** switching Feed → Profile → Settings feels like flipping between tabs on your phone — immediate, with the destination's own content animating in on its own terms (grid stagger, etc.) rather than the whole screen performing a transition first.

### 1b. Profile's internal tab routes (Videos/Shorts/Posts/Stats) — the tab bar carries the motion, not the page

- [ ] These are technically separate routes (`ProfilePage` re-renders for each) but behave like an in-page tab switch, not a navigation. The motion budget here is already spent correctly elsewhere — the `ProfileTabBar`'s sliding `layoutId` underline (from §8 of this doc) _is_ the transition.
- [ ] Add only a fast opacity crossfade on `ProfileTabContent.tsx`'s panel — `initial={{ opacity: 0 }}`, `animate={{ opacity: 1 }}`, ~`durations.micro`–`durations.fast` (120–150ms), no vertical movement, no scale. This exists purely so content doesn't hard-cut while the underline is still sliding; it should be barely noticeable on its own.

### 1c. Upload Hub → a specific wizard (Video/Short/Post) — the one place a real "entering" cue is earned

- [ ] This is a genuine drill-down: the user is choosing a path and stepping into a distinct flow, structurally different from switching tabs. Give it a directional forward-entry animation: `initial={{ opacity: 0, x: 16 }}`, `animate={{ opacity: 1, x: 0 }}`, `springs.snappy`, applied only to the wizard's root content, not to `UploadHub` itself.
- [ ] **Direction must be correct, not just decorative.** Use react-router's `useNavigationType()` to distinguish `PUSH` (user chose a wizard from the Hub — play the forward-entry animation described above) from `POP` (user hit back — reverse it: exit toward `x: 16` instead of replaying the forward animation in reverse-looking-wrong). Don't hardcode one animation for both directions; check the navigation type and branch.
- [ ] This same treatment does **not** extend to the finalize sub-steps (`/finalize/:id` and its internal thumbnail/details steps) — those already have their own step-to-step motion via the wizard's internal `AnimatePresence`/`layout` handling (see the upload-flow-redesign doc, §2/§3/§4). Applying this section's route-level animation on top of that would double up motion on the same transition.

### 1d. Auth routes (Login/Register/etc.)

- [ ] Out of scope for this section — confirmed in `AppRoutes.tsx` that these sit outside `PageWrapper` entirely, in their own route branch (behind `GuestRoute`), so they're structurally isolated already. Leave as a separate, later decision if you want dedicated motion there; don't fold it into this scheme.

---

## 2. Feed & Grids

**Files:** `packages/client/src/features/feed/Feed.tsx`, `packages/client/src/features/video/pages/VideoGrid.tsx`, `packages/client/src/features/short/pages/ShortGrid.tsx`, `packages/client/src/features/post/pages/PostGrid.tsx`, `packages/client/src/features/video/hooks/useGridCols.ts`, `packages/client/src/features/short/hooks/useShortGridCols.ts`, `packages/client/src/features/feed/hooks/useFeedColumns.ts`

Currently: grids (`grid gap-4 ${COL_CLASS[columns]}`) render children with no entrance animation; column count changes on resize snap instantly; `useLiveVideoFeed`/`useLiveShortsFeed` append new pages with no visual distinction from initial content.

- [ ] **Initial load stagger:** wrap each grid block in a `motion.div` container with `variants` using `staggerChildren: stagger.tight`. Each card: `initial={{ opacity: 0, y: 16 }}`, `animate={{ opacity: 1, y: 0 }}`, spring `springs.bouncy`. Trigger only on first mount of a given block (use a ref/flag — don't re-stagger on every re-render, e.g. when a live socket event updates one card's like count).
- [ ] **Infinite-scroll append:** only newly-appended cards animate in (key off `item.id`, rely on `AnimatePresence`/`layout` — existing items should NOT re-animate when new ones are appended below them). This requires cards to be keyed correctly, which they already are (`key={video.id}` etc. — confirmed in `Feed.tsx`).
- [ ] **Column reflow:** wrap each grid item in `motion.div layout` with `springs.smooth`, so when `useFeedColumns`/`useGridCols` changes `columns` on window resize, cards smoothly reflow into new positions instead of snapping. Be careful: enable `layout` only on the item wrapper, not on internal card content that has its own transitions (nested `layout` can conflict — test carefully).
- [ ] **Skeleton rows during pagination fetch** (`VideoCardSkeleton` appended while `videosFetching`): fade in with `opacity 0→1`, 150ms — currently pops in instantly per the conditional render in `Feed.tsx`.
- [ ] **Momentum scroll:** initialize `lenis` on the `<main>` scroll container in `PageWrapper.tsx` (the element with `overflow-y-auto`). Standard config (`duration: 1.1, easing: (t) => Math.min(1, 1.001 - Math.pow(2, -10 * t))`) is enough — don't over-tune this, subtlety is the point.

**Feels premium when:** scrolling the feed has weight and momentum instead of feeling like a static scrollbar-drag, and content arriving from pagination feels like it's _joining_ the feed rather than appearing.

---

## 3. Cards — Video / Post / Short

**Files:** `packages/client/src/features/video/pages/VideoCard.tsx`, `packages/client/src/features/post/pages/PostCard.tsx`, `packages/client/src/features/short/components/ShortRailCard.tsx`, `packages/client/src/shared/ui/card/CardShell.tsx`, `packages/client/src/shared/ui/card/MediaDurationBadge.tsx`, `packages/client/src/shared/ui/card/MediaVisibilityBadge.tsx`, `packages/client/src/shared/ui/card/UnlistedCountdownBadge.tsx`, `packages/client/src/shared/ui/card/CardOptionsMenu.tsx`

**Hard constraint respected: no `hover:scale-*` on cards or thumbnails.** Use these instead:

- [ ] **Hover elevation, not size:** on `CardShell.tsx`, replace/augment any hover treatment with a shadow crossfade — `shadow-none` → `shadow-lg shadow-black/30` (dark theme) via `transition-shadow duration-200`. This reads as "this card lifted toward you" without the cheap zoom.
- [ ] **Thumbnail parallax on hover** (`VideoCardThumbnail`, `ShortCardThumbnail`): on hover, `motion.img` `y: 0 → -3px` with `springs.snappy` — a whisper of motion, not a jump. Combine with the shadow lift above for a cohesive "card comes forward" feeling.
- [ ] **`CardOptionsMenu` dropdown:** currently opens with no transition. Wrap the menu panel in `AnimatePresence` + `motion.div`: `initial={{ opacity: 0, scale: 0.95, y: -4 }}`, `animate={{ opacity: 1, scale: 1, y: 0 }}`, `exit={{ opacity: 0, scale: 0.96 }}`, `transformOrigin: 'top right'`, `springs.snappy`. This is used on nearly every card — high multiplier on a small change.
- [ ] **`MediaDurationBadge` / `MediaVisibilityBadge`:** on card mount, spring-pop in slightly _after_ the thumbnail (delay ~0.1s), `scale: 0.8 → 1, opacity: 0 → 1`, `springs.bouncy`. Small detail, but badges "arriving" after the thumbnail reads as intentional layering rather than everything existing at once.
- [ ] **`UnlistedCountdownBadge`:** if the days-left number changes between renders, animate the digit swap — wrap the number in `AnimatePresence mode="popLayout"` keyed on the value, `initial={{ y: -8, opacity: 0 }}`, `exit={{ y: 8, opacity: 0 }}` — a mini odometer effect.
- [ ] **Delete/visibility confirm flows** (`VideoCard.tsx`, `PostCard.tsx` — both wire up `ConfirmModal`/`MultiStepConfirmDelete`/`Modal` for edit, visibility toggle, delete): once Modal itself is fixed (§5), these get the improved transition for free — no extra work needed here, just confirm after §5 that edit/delete modals on cards open/close correctly.

**Feels premium when:** hovering a card feels tactile and considered, and the options menu feels like a native OS context menu, not a bootstrap dropdown.

---

## 4. Shorts Theater Mode — highest priority, biggest payoff

**Files:** `packages/client/src/features/feed/Feed.tsx` (owns `theaterOpen` state + overlay), `packages/client/src/features/short/pages/ShortPlayer.tsx`, `packages/client/src/features/short/components/ShortRailCard.tsx`, `packages/client/src/features/short/useShort.ts`

Currently: clicking a `ShortRailCard` thumbnail calls `handleThumbnailClick` → `setTheaterOpen(true)`, and `Feed.tsx` conditionally renders a `fixed inset-0` overlay containing `ShortPlayer`. This is a hard cut — `{theaterOpen && <div>...}` — with no transition at all, and next/prev (`goNext`/`goPrev` from `useShort`) also just swap the `short` prop with no visual transition between shorts.

This is your single highest-leverage animation because it's the "TikTok moment" — the interaction pattern users most associate with premium short-form video products.

- [ ] **Shared-element expansion:** give the thumbnail in `ShortRailCard.tsx` a `layoutId={`short-thumb-${short.id}`}` on its image/container. Give the theater's media container in `ShortPlayer.tsx` (or a wrapper in `Feed.tsx`) the **same** `layoutId` when rendering the active short. Wrapping both in a shared `<LayoutGroup>` and using `AnimatePresence`, framer-motion will automatically morph the small grid thumbnail into the full theater view instead of a hard swap. Use `springs.cinematic` for the layout transition.
- [ ] **Backdrop:** `bg-black/80` currently appears instantly (`theaterOpen && <div className="fixed inset-0 z-50 bg-black/80...">`). Convert to `motion.div` with `initial={{ opacity: 0 }}`, `animate={{ opacity: 1 }}`, `exit={{ opacity: 0 }}`, `durations.base`.
- [ ] **Vertical swipe navigation:** add drag gesture support to the theater's media container — `motion.div drag="y"`, `dragConstraints={{ top: 0, bottom: 0 }}`, `dragElastic={0.6}` (rubber-band feel at extremes), and in `onDragEnd`, check `info.offset.y` and `info.velocity.y` — if it exceeds a threshold (e.g. `offset.y < -80 || velocity.y < -500`) call `handleShortNext`, mirror for `goPrev`. This replaces/supplements the chevron-button-only navigation currently in `ShortPlayer.tsx`.
- [ ] **Short-to-short transition:** when `activeIndex` changes (via swipe or chevrons), animate the outgoing short sliding/fading out while the incoming short slides/fades in — `AnimatePresence mode="popLayout"` keyed on `short.id`, direction-aware (slide up if going next, down if going prev — track direction in a ref, similar to how carousels do it). Use `springs.cinematic`.
- [ ] **Chevron buttons** (`ChevronUp`/`ChevronDown` in `ShortPlayer.tsx`): on click, `whileTap={{ y: direction === 'up' ? -4 : 4 }}` spring-back — a physical nudge instead of pure color feedback.
- [ ] **Close button** (`X` in `Feed.tsx`'s theater overlay): spring-pop on mount, `initial={{ scale: 0, opacity: 0 }}`, `animate={{ scale: 1, opacity: 1 }}`, small delay after backdrop so it doesn't compete visually with the shared-element expansion.
- [ ] **Prefetch indicator:** `useLiveShortsFeed`'s `loadMoreShorts` fires near the end of the list (`SHORTS_PREFETCH_THRESHOLD`) — while this is silent/background today, that's correct; don't add a visible loading state here, it would interrupt the swipe flow. Only worth revisiting if a genuine stall is observed.

**Feels premium when:** tapping a short thumbnail feels like it "opens up" into the theater rather than a different screen appearing, and swiping between shorts has physical weight (resistance, velocity-based flick) rather than being button-only.

---

## 5. Modals & Sheets

**Files:** `packages/client/src/shared/ui/overlay/Modal.tsx`, `packages/client/src/shared/ui/overlay/ConfirmModal.tsx`, `packages/client/src/shared/ui/overlay/MultiStepConfirmDelete.tsx`

Currently: `Modal.tsx` does `if (!isOpen) return null;` — a hard unmount with **no exit animation possible** in the current structure, since the component is gone from the tree before any exit transition could run. The backdrop and dialog do have `transition-opacity`/`transition-all` classes on them, but they're meaningless because the elements never linger in a "closing" state.

- [ ] **Restructure `Modal.tsx` to always render, gated by `AnimatePresence`:** move the `if (!isOpen) return null` check to `{isOpen && (...)}` _inside_ `createPortal`, wrapped in `<AnimatePresence>`, so exit animations can actually play before unmount.
- [ ] **Backdrop:** `motion.div`, `initial={{ opacity: 0 }}`, `animate={{ opacity: 1 }}`, `exit={{ opacity: 0 }}`, `durations.fast`.
- [ ] **Dialog panel:** `motion.div`, `initial={{ opacity: 0, scale: 0.96, y: 8 }}`, `animate={{ opacity: 1, scale: 1, y: 0 }}`, `exit={{ opacity: 0, scale: 0.97, y: 4 }}`, `springs.snappy`. Confident and quick — a modal should feel like it _arrives_, not drifts in.
- [ ] **Mobile breakpoint → bottom sheet:** below `sm`/`md` (check `packages/shared/src/constants/breakpoints.constants.ts` for the project's existing breakpoint values and reuse them, don't invent new ones), swap `Modal`'s dialog for a `vaul` `Drawer` — drag handle at top, drag-to-dismiss, snap point at ~90% height for taller content (e.g. `PostEditForm`, `VideoEditForm` when opened via card edit flows). This single change will make every edit/delete/confirm flow on mobile feel like a native app bottom sheet instead of a shrunken desktop dialog.
- [ ] **`ConfirmModal`'s icon badge** (the circular `Trash2`/`AlertTriangle`/`ShieldAlert` icon): spring-pop in with a slight delay after the dialog itself, `initial={{ scale: 0.5, opacity: 0 }}`, `animate={{ scale: 1, opacity: 1 }}`, `springs.bouncy` — mirrors the quality of `SuccessStep`'s icon entrance for consistency between "good news" and "confirm action" moments.
- [ ] **`MultiStepConfirmDelete`:** currently swaps `ConfirmModal`'s title/description/intent instantly between steps 1→2→3 (just re-renders new props into the same modal). Add a horizontal step transition: wrap the title+description block in `AnimatePresence mode="wait"` keyed on `step`, `initial={{ opacity: 0, x: 16 }}`, `animate={{ opacity: 1, x: 0 }}`, `exit={{ opacity: 0, x: -16 }}`, `durations.fast`. As the intent escalates from `warning` (steps 1-2) to `danger` (step 3), consider a subtle color transition on the icon badge background too (`bg-primary-muted` → `bg-error-subtle`) rather than an instant swap — reinforces that the stakes are rising.

**Feels premium when:** every dialog opens/closes with weight and closes cleanly instead of vanishing, and mobile users get a sheet that feels designed for touch, not a desktop leftover.

---

## 6. Toasts & Celebrations

**Files:** `packages/client/src/shared/ui/overlay/Toast.tsx`, `packages/client/src/shared/ui/overlay/ToastContainer.tsx`, `packages/client/src/features/creator/components/BadgeToast.tsx` **[REFERENCE QUALITY — already done well]**, `packages/client/src/features/creator/hooks/useCreatorCelebration.ts`

Currently: `Toast.tsx` fakes an exit animation with local `isLeaving` state + `setTimeout(onClose, 200)` — it works but is manual and doesn't share the spring vocabulary; there's also no entrance animation defined via motion (only CSS `transition-all`). `ToastContainer.tsx` renders a plain `.map()` — when a toast is removed from the array, the remaining ones just jump into its place.

- [ ] **Rewrite `Toast.tsx` to match `BadgeToast.tsx`'s pattern exactly:** wrap in `motion.div`, `initial={{ opacity: 0, y: -12, scale: 0.95 }}`, `animate={{ opacity: 1, y: 0, scale: 1 }}`, `exit={{ opacity: 0, y: -8, scale: 0.97 }}`, `springs.snappy`. Delete the `isLeaving` state / manual `setTimeout` — let `AnimatePresence`'s `exit` + `onExitComplete` (or the existing `duration` timer calling `onClose` directly) handle removal cleanly.
- [ ] **Wire `AnimatePresence` in `ToastContainer.tsx`** around the `.map()` output, each `Toast` needs `layout` so that when one toast leaves, the ones below/above it smoothly slide to fill the gap instead of snapping.
- [ ] **Confetti + badge sync:** `useCreatorCelebration.ts` already queues badge/milestone events; `canvas-confetti` is a dependency but its trigger site wasn't found near this hook in the files reviewed — confirm where it fires (likely alongside `BadgeToast`'s mount) and make sure the confetti burst and the badge icon's spring-pop (`BadgeToast`'s icon container) are timed together, not sequential. For milestone/badge unlocks specifically, this is a moment worth being disproportionately delightful — consider increasing confetti `particleCount`/`spread` for `creatorMilestone` events vs. regular `badge` events, so bigger achievements _feel_ bigger.

**Feels premium when:** toasts feel like they belong to the same design system as the badge celebrations, and a stack of toasts reflows fluidly instead of jumping when one disappears.

---

## 7. Upload Flow — extend existing quality, don't rebuild it

**Files:** `packages/client/src/features/upload/components/UploadStepper.tsx` **[REFERENCE]**, `MediaDropzone.tsx` **[REFERENCE]**, `SuccessStep.tsx` **[REFERENCE]**, `TagInput.tsx` **[REFERENCE]**, `CategoryPicker.tsx` **[REFERENCE]**, `UploadThumbnailStep.tsx`, `ThumbnailPicker.tsx`, `FloatingInput.tsx`, `FloatingTextarea.tsx`, `VisibilitySelector.tsx`

This flow is already the most polished part of the app. Bring the remaining pieces up to the same bar rather than changing what works:

- [ ] **`ThumbnailPicker.tsx` / `UploadThumbnailStep.tsx`:** if thumbnail candidates are presented as a selectable grid (similar pattern to `CategoryPicker`), apply the identical selection treatment: `whileTap={{ scale: 0.94 }}` + a spring border/ring highlight on selection, using `springs.snappy`.
- [ ] **`VisibilitySelector.tsx`:** if this is a segmented control (public/unlisted/private-style), add a sliding background indicator using `layoutId` (see §8's tab underline pattern) rather than each option independently toggling its own background color.
- [ ] **`FloatingInput.tsx` / `FloatingTextarea.tsx`:** floating labels should animate their `y`/`scale`/color transition on focus via `motion` + `springs.snappy` rather than relying purely on CSS `:focus` + `peer` selectors (check current implementation — if already CSS-driven and looks good, this is optional polish, not a gap).
- [ ] **`UploadStepper.tsx`** already has a nice current-step pulse and progress-line fill — no changes needed, it meets the bar.
- [ ] **`MediaDropzone.tsx`** already has an idle float animation on the upload icon and a drag-state morph — no changes needed. Just confirm the same `springs.ts` values get backfilled here for consistency (currently uses inline `duration: 2.2, repeat: Infinity` for the idle float — fine to leave inline since it's a continuous ambient loop, not a discrete interaction).

**Feels premium when:** a user moving from `CategoryPicker` to `ThumbnailPicker` to `TagInput` never notices a dip in polish — every step of the wizard feels like it was designed by the same hand.

---

## 8. Navigation — Navbar, Sidebar, Tabs

**Files:** `packages/client/src/app/layout/Navbar.tsx`, `packages/client/src/app/layout/Sidebar.tsx`, `packages/client/src/features/profile/components/ProfileTabBar.tsx`, `packages/client/src/shared/ui/misc/ViewModeToggle.tsx`, `packages/client/src/features/profile/components/VisibilityFilter.tsx`

- [ ] **`ProfileTabBar.tsx` sliding underline** — do this one first, it's the cheapest change on this entire list relative to visible impact. Currently each `Link`'s `border-b-2` independently toggles between `border-primary` and `border-transparent` — the active indicator snaps between tabs. Instead: render a single `motion.div layoutId="profile-tab-underline"` absolutely positioned under the active tab (or use a wrapping approach where each tab is `position: relative` and the underline is a sibling that measures/moves) — with `layoutId` shared across all tab instances, framer-motion automatically animates it sliding from the old active tab to the new one. Use `springs.smooth`.
- [ ] **`ViewModeToggle.tsx`** (grid/list toggle): same `layoutId` sliding-background pattern — a `motion.div` behind the active icon (`bg-surface-overlay`) that slides between "grid" and "list" positions instead of each button independently toggling its own background class.
- [ ] **`VisibilityFilter.tsx`:** if this is also a segmented pill control, apply the identical sliding-background pattern for consistency across all toggle-style controls in the app — establishing this as _the_ pattern for any binary/multi-option selector reinforces the "one coherent app" feeling.
- [ ] **Sidebar collapse/expand** (`Sidebar.tsx`): currently `'transform transition-all duration-300 ease-in-out'` on the `<aside>`, animating `width` via Tailwind's `md:w-14`/`md:w-56` classes. `transition-all` on `width` is **not GPU-accelerated** and can visibly jank on lower-end devices, especially with content reflowing inside simultaneously. Replace with an explicit `motion.aside` animating a numeric `width` (e.g. `56px` vs `224px`, matching current `w-14`/`w-56` values) via `springs.smooth`. Keep the mobile drawer's `translate-x` as `transform`-based (already efficient) but consider swapping the raw CSS transition for a `motion.aside` with `springs.smooth` for consistency with the rest of the app's spring vocabulary — plus animate the backdrop (`bg-black/70 backdrop-blur-sm`) fade in sync rather than its current instant appearance (`isMobileOpen && <div className="fixed inset-0...">`).
- [ ] **`Navbar.tsx` theme toggle** (`Sun`/`Moon` icon swap on `toggle`): currently an instant conditional render (`{isDark ? <Sun /> : <Moon />}`). Wrap in `AnimatePresence mode="wait"`, `initial={{ rotate: -90, scale: 0.5, opacity: 0 }}`, `animate={{ rotate: 0, scale: 1, opacity: 1 }}`, `exit={{ rotate: 90, scale: 0.5, opacity: 0 }}`, `springs.snappy` — a satisfying little "flip" that matches the weight of an intentional light/dark switch.
- [ ] **Nav item active state** (`Sidebar.tsx`'s `NavLink`s): the icon `strokeWidth` already changes between `1.75`/`2.5` on active state — nice detail already present. Optionally animate the background pill (`bg-primary-muted`) the same sliding `layoutId` way as the profile tabs, since sidebar nav is structurally the same pattern (list of mutually-exclusive selectable items).
- [ ] **Notification bell** (`Navbar.tsx`): the `animate-ping` dot is a fine ambient indicator for "there's something new" — leave it. Additionally, when a _new_ notification specifically arrives (not just on mount), trigger a one-shot bell "shake": `animate={{ rotate: [0, -12, 10, -8, 4, 0] }}`, short duration (~0.5s), fires once per new-notification event rather than looping.

**Feels premium when:** every toggle-style control in the app (profile tabs, view mode, visibility filter, theme switch) shares the exact same sliding/morphing pattern, so the whole app reads as one considered system rather than a collection of independently-styled widgets.

---

## 9. Micro-interactions — buttons, inputs, counts

**Files:** `packages/client/src/shared/ui/primitives/Button.tsx`, `packages/client/src/features/auth/components/OtpInput.tsx`, `packages/client/src/features/upload/components/FloatingInput.tsx`, `formatCount` usages (likes/views across `PostFooter.tsx`, `VideoCardFooter.tsx`, `ShortCardFooter.tsx`)

- [ ] **`Button.tsx` tap feedback — do this app-wide, it's the single highest-multiplier change on this whole list.** Currently a plain `<button>` with only `hover:bg-*` and `transition-colors`. Convert the base element to `motion.button` (keep `forwardRef` — framer-motion supports ref forwarding) and add `whileTap={{ scale: 0.97 }}` with `springs.snappy`. This is explicitly **not** the hover-scale pattern you ruled out — it's a _press_ response, which is standard, expected, and reads as native/tactile rather than gimmicky. Apply consistently across all variants (`primary`, `secondary`, `outline`, `ghost`, `danger`) and sizes.
  - Note: `isLoading` disables the button — make sure `whileTap` doesn't fire when `disabled || isLoading` (framer-motion respects the `disabled` attribute correctly on `motion.button`, but verify visually).
- [ ] **`OtpInput.tsx`:** on each digit entry, a very quick spring-pop on that specific input box (`scale: 1 → 1.08 → 1`, ~150ms) — reinforces "code accepted" per digit rather than a flat instant fill. Keep it subtle; this is a security-adjacent flow, playful should not mean distracting.
- [ ] **Live count updates** (likes/views via `formatCount`, updated through the socket hooks like `useLiveVideoFeed`/`useMediaStatusSocket`): when a count changes from a live update (not initial render), animate the digit transition — `AnimatePresence mode="popLayout"` keyed on the formatted value, brief `y`-offset crossfade. Do **not** animate this on initial page load/render — only on genuine live deltas, otherwise every card entrance would also trigger a count "roll" and dilute the effect.
- [ ] **Focus rings:** current `focus:ring-2 focus:ring-offset-2` (in `Button.tsx`) and `focus:border-primary` (various inputs) are instant via browser default. Optional polish: this is one of the few places where a plain CSS `transition` (already partially present via `transition-colors`) is _fine_ to leave as-is — focus rings benefiting from motion is marginal, don't over-invest here.

**Feels premium when:** every button press has a tiny, consistent "give" to it, and numbers that update live feel alive rather than just changing.

---

## 10. Skeleton → Content Handoff

**Files:** `packages/client/src/shared/ui/skeleton/Skeleton.tsx`, `FeedSkeleton.tsx` (both the shared one and `features/feed/skeleton/FeedSkeleton.tsx`), `VideoCardSkeleton.tsx`, `PostCardSkeleton.tsx`, `ShortCardSkeleton.tsx`, `ProfileSkeleton.tsx`, `SettingsSkeleton.tsx`, `AuthSkeleton.tsx`

Currently: `Skeleton.tsx` renders a `div` with a `skeleton-shimmer` CSS class (shimmer loop, defined presumably in `index.css`/`theme.css`) — the shimmer itself is fine and ambient. The gap is the **handoff**: when real data resolves (e.g. `Feed.tsx`'s `if (videosInitialLoading && videos.length === 0) return <FeedSkeleton />`), the swap from skeleton to content is a conditional-render hard cut.

- [ ] At each of these swap points, wrap the skeleton/content pair in `AnimatePresence mode="wait"` (or, for a true crossfade rather than sequential, don't use `"wait"` — let skeleton `exit` and content `initial`→`animate` overlap by ~100ms): skeleton `exit={{ opacity: 0 }}`, content `initial={{ opacity: 0 }}` → `animate={{ opacity: 1 }}`, `durations.fast`.
- [ ] Combine with §2's grid entrance stagger for content — the skeleton fades out roughly as the real cards stagger in underneath. This avoids the "flash of empty/replaced content" feeling and reads as an intentional reveal.

**Feels premium when:** loading states dissolve into content rather than being replaced by it.

---

## 11. Empty & Error States

**Files:** `VideoEmptyState.tsx`, `ShortEmptyState.tsx`, `PostEmptyState.tsx`, `VideoErrorState.tsx`, `PostErrorState.tsx`, `ShortErrorState.tsx`

- [ ] Entrance: `initial={{ opacity: 0, y: 12 }}` → `animate={{ opacity: 1, y: 0 }}`, `durations.base` — these currently likely render instantly since they're simple conditional JSX in `Feed.tsx` and equivalents.
- [ ] Consider a subtle idle animation on whatever icon these states use (mirroring `MediaDropzone.tsx`'s idle float — `y: [0, -4, 0]`, `duration: 2.2, repeat: Infinity`) so empty states feel designed rather than static filler.
- [ ] Error states' "Retry" button gets the same `whileTap` treatment as `Button.tsx` (should be automatic once §9 is done, assuming these use the shared `Button` component — verify).

**Feels premium when:** even "nothing to show" moments feel considered instead of feeling like an afterthought.

---

## Priority Order (effort vs. impact)

If implementing sequentially rather than all at once, this order maximizes visible improvement per hour spent:

1. **§0** — springs.ts foundation (blocks everything else from being consistent)
2. **§9.1** — `Button.tsx` `whileTap` (touches nearly every screen in the app, ~15 min)
3. **§8** — `ProfileTabBar`/`ViewModeToggle` sliding indicators (cheap, high visible payoff)
4. **§6** — Toast fix to match `BadgeToast` quality
5. **§5** — Modal `AnimatePresence` fix (unblocks proper exit animations everywhere Modal is used — cards, upload edit flows, confirm dialogs)
6. **§1** — Route transitions
7. **§4** — Shorts theater shared-element + swipe (highest total effort, highest single-feature payoff — the "wow" feature)
8. **§2 + §10** — Grid stagger + skeleton handoff (pairs naturally, do together)
9. **§3** — Card-level polish (elevation, badges, options menu)
10. **§7 + §11** — Remaining upload polish + empty states (lowest urgency, existing upload flow is already strong)

## Definition of Done (for whoever implements this)

- [ ] Every new spring/duration value traces back to `shared/motion/springs.ts` — no orphaned magic numbers.
- [ ] `prefers-reduced-motion` is respected globally (test via OS/browser setting, not just code review).
- [ ] Nothing in this list uses `hover:scale-*` or similar hover-growth on buttons, cards, or icons.
- [ ] Test on a throttled/low-end device profile (Chrome DevTools CPU throttle 4x–6x) — bouncy ≠ heavy; if anything drops frames, reduce `mass`/increase `damping` before removing the animation.
- [ ] Test with real data volumes (50+ feed items, 20+ tags, etc.) — stagger and layout animations that feel great with 6 items can feel sluggish with 60; cap stagger delay or disable it past a threshold if needed.

# Phone Number Login — Implementation Checklist

> **Status: ON HOLD.** Phase 0 (MSG91 + DLT registration) requires a registered
> business entity and KYC documents, which this project doesn't have yet while
> pre-launch. Ship with Google + Email only for now; resume this checklist once
> the business entity exists — start at Phase 0, everything else follows in order.

**Scope:** Add phone + password as a third, equal auth method alongside Google and
Email. Mirrors the existing email/password flow — same lockout logic, same
OTP-verification pattern, same rate limits — just keyed on phone instead of email,
and SMS instead of email delivery.

## Locked decisions

- [ ] Launch order: ship Google + Email now (two options). Add Phone as the third
      once Phase 0 is unblocked.
- [ ] Three equal, stacked login/register options once phone ships: Google, Email,
      Phone. No Truecaller, no fourth option.
- [ ] Phone accounts use a password, not OTP-on-every-login. OTP is sent once at
      signup to verify the number, and reused for password reset — never for
      routine login.
- [ ] Phone registration flow: select country → enter phone number → enter name and
      password → submit → OTP sent → enter OTP → account active.
- [ ] SMS provider: MSG91 for now, built behind a provider interface (same pattern
      already used for storage/image/video) so a global provider can be added later
      for non-Indian numbers without touching calling code.
- [ ] Phone-based password reset ships in the same release as phone login — an
      account with only a phone (no email) has no other recovery path.

---

## Phase 0 — Provider account & compliance (do this first)

SMS in India requires DLT (Distributed Ledger Technology) registration with TRAI
before any transactional SMS can be sent. This is a paperwork step, not a code step,
and can take 1–3 business days.

- [ ] Sign up for an MSG91 account (India entity signup for the best local rates).
- [ ] Register as a Principal Entity on the DLT portal of any one telecom operator.
      Requires basic business KYC documents.
- [ ] Register a Sender ID (6-letter alphabetic header) under that entity.
- [ ] Register the OTP message template on DLT with the exact text to be sent.
      MSG91 will reject sends that don't match a registered template.
- [ ] Note the MSG91 Auth Key, Sender ID, and DLT Template ID for use as env vars.
- [ ] Ask MSG91 support about any current startup credit program at signup — don't
      assume a specific free amount without confirming current terms.
- [ ] Confirm MSG91's current OTP pricing for India at signup.

---

## Phase 1 — Shared package (`packages/shared`)

- [ ] Add an isomorphic phone-number validation library (works in both browser and
      Node) for real E.164 parsing/validation instead of a hand-rolled regex.
- [ ] Add an OTP-purpose constant/type that includes phone verification and phone
      password reset, alongside the existing email ones.
- [ ] Extend the auth-providers constant to distinguish phone-password accounts from
      email-password accounts. Audit every place that currently assumes the
      email/password provider value before changing this — it touches the user
      model, the repository, and anywhere that checks auth provider type.
- [ ] Add phone-related public route paths to the existing public-paths list.
- [ ] Add a curated country list (dial code, ISO code, name, flag) for the country
      picker, leading with India. Keep it short at first — expand only once real
      international signups show up.
- [ ] Add a reusable phone validator to the shared user schema.
- [ ] Add phone registration, phone login, verify-phone, request-phone-verification,
      request-phone-password-reset, and complete-phone-password-reset schemas,
      mirroring the existing email schemas.
- [ ] Add the corresponding inferred TypeScript types for all new schemas.
- [ ] Add a phone-masking utility, mirroring the existing email-masking one, for
      consistent masked display in toasts and verification screens.
- [ ] Export all new constants, schemas, types, and utils from the shared package's
      entry point.
- [ ] Rebuild the shared package and confirm the new exports are available before
      starting server/client work.

---

## Phase 2 — Server: environment & database

- [ ] Add SMS provider config to the server's auth env schema: provider name and the
      three MSG91 values from Phase 0.
- [ ] Add the same values to `.env.example` with placeholder values.
- [ ] Relax the user model's `email` field to optional, with its unique index
      switched to sparse (since phone-only accounts won't have one).
- [ ] Add `phone` and `isPhoneVerified` fields to the user model, same shape as the
      existing email/isEmailVerified fields, with a sparse unique index on phone.
- [ ] Add an application-level validation hook ensuring every user has at least one
      of email or phone — MongoDB can't express that as a schema-level constraint.
- [ ] Update the user document TypeScript interface to include the new optional
      phone field.
- [ ] Plan the index rebuild for the email field's new sparse unique index. Low risk
      pre-launch with no real user data, but don't skip it once there is any.
- [ ] Define an SMS provider interface (same style as the existing image/storage
      provider interfaces) with a single send-OTP method.
- [ ] Implement an MSG91 provider class fulfilling that interface, using MSG91's
      Send OTP API. Send your own app-generated OTP rather than letting MSG91
      generate/verify it internally, so verification logic stays identical to the
      email flow.
- [ ] Wire the new provider into the existing provider factory, keyed off the new
      `SMS_PROVIDER` env var, exporting a single `smsProvider` instance — same
      pattern as the existing storage/image/video providers.
- [ ] Leave a clear seam here for adding a second, globally-capable provider later
      (e.g. Twilio Verify), routed by the number's country code — no other files
      should need to change when that day comes.

---

## Phase 3 — Server: SMS delivery queue

Mirror the existing email module's BullMQ queue + worker pattern so a slow SMS
provider doesn't block the request and failures get retried automatically.

- [ ] Add job-type definitions for an OTP SMS job.
- [ ] Add a queue module for SMS, mirroring the email queue module's structure and
      exporting a `queueOtpSms` function.
- [ ] Add a worker module for SMS, mirroring the email worker's structure, with the
      job processor calling the SMS provider's send-OTP method. Reuse the same
      retry/backoff configuration as the email worker.
- [ ] Add a barrel export for the new SMS module.
- [ ] Register the new SMS worker's startup call alongside the existing email
      worker's startup call.
- [ ] Add the new SMS queue name to shared constants, next to the existing email
      queue name.

---

## Phase 4 — Server: repository, services, controllers, routes

- [ ] Add repository functions: find-by-phone, find-by-phone-with-password,
      create-phone-user, mark-phone-verified.
- [ ] Add a phone-user creation data type alongside the existing local-user one.
- [ ] Generalize the OTP-cooldown utility's purpose parameter to use the shared
      OTP-purpose type from Phase 1, so the new phone purposes work without changing
      the utility's logic.
- [ ] Add phone-verification send/verify functions to the auth verification service,
      mirroring the existing email-verification functions exactly — same attempt
      limiting, same TTL, just phone/SMS instead of email/nodemailer.
- [ ] Add phone password-reset request/complete functions, mirroring the existing
      email password-reset service, keyed on the new phone-reset purpose. Reuse the
      existing password-update repository function, which is already identifier
      agnostic.
- [ ] Add a new phone auth service with register-phone and login-phone functions,
      mirroring the existing local register/login service functions — same lockout
      logic, same dummy-hash timing-attack protection, keyed on phone instead of
      email. Confirm the existing refresh/logout service functions are already
      identifier-agnostic and need no duplication.
- [ ] Add a new phone auth controller mirroring the existing core, verify, and
      password controllers — register, login (setting the same refresh-token and
      CSRF cookies as the existing login), request-verification, verify,
      request-password-reset, complete-password-reset.
- [ ] Add the new phone routes: register-phone, login-phone,
      send-phone-verification, verify-phone, request-phone-password-reset,
      reset-phone-password. Apply the same rate limiters used on the equivalent
      email routes (auth limiter on register/login, OTP limiter on the
      verification/reset routes).

---

## Phase 5 — Client

- [ ] Add a country-select component for the phone picker, defaulting to India.
- [ ] Add a phone-field component that composes the country selector and a numeric
      input into a single E.164 string before handing it to the form — so the rest
      of the form, and the API contract, sees one plain phone string, same shape as
      the existing email field.
- [ ] Add API mutations for register-phone, login-phone, send-phone-verification,
      verify-phone, request-phone-password-reset, and reset-phone-password,
      mirroring the existing email mutations.
- [ ] Add phone register and phone login form hooks, mirroring the existing
      email register/login hooks' structure and error handling.
- [ ] Add a three-way method switcher to the login and register pages: Google,
      Email, Phone. Google stays a single-click redirect; Email/Phone reveal their
      respective forms.
- [ ] Add a phone verification screen after successful phone registration, reusing
      the existing OTP input component and the layout of the existing email
      verification screen, pointed at the phone endpoints and using the masked
      phone display.
- [ ] Add phone-mode variants of the existing forgot-password/reset-password pages,
      pointed at the phone password-reset mutations.
- [ ] Add a phone icon to the auth icon set for the new method switcher.

---

## Phase 6 — Security & cost controls

- [ ] Confirm the OTP rate limiter and OTP cooldown both apply to the new phone OTP
      endpoints exactly as they do for email — this is the primary defense against
      SMS-pumping fraud.
- [ ] Confirm the auth rate limiter applies to the new register-phone and
      login-phone routes.
- [ ] Confirm phone format validation happens at the route boundary, rejecting
      malformed numbers before they reach the SMS provider and cost a credit.
- [ ] Consider a daily SMS spend guard: a counter checked against a budget env var,
      refusing new OTP sends once exceeded. Not required for launch, but cheap
      insurance against a misconfigured client or scraper looping the send
      endpoint.
- [ ] Confirm the MSG91 auth key is only ever read server-side and never exposed to
      the client bundle.

---

## Phase 7 — Testing

- [ ] Confirm with MSG91's docs whether their sandbox/test mode sends are free or
      discounted before running integration tests repeatedly.
- [ ] Unit test the MSG91 provider class with a mocked network call.
- [ ] Manually test the full loop end-to-end: register → receive SMS → verify →
      login with password → logout → login again.
- [ ] Test failure paths: wrong OTP (should increment attempts and eventually
      lock), expired OTP, duplicate phone registration (should conflict), OTP
      resend cooldown.
- [ ] Confirm existing email-only accounts are unaffected by the schema changes.

---

## Phase 8 — Rollout

- [ ] Deploy with the SMS provider env vars set in the real environment, not just
      the example file.
- [ ] Watch MSG91's delivery dashboard for the first real signups — confirm
      delivery time and success rate before relying on it at volume.
- [ ] Set a reminder to revisit international coverage once the first non-Indian
      signup attempt shows up in the country picker — that's the actual signal to
      add a second SMS provider, not a guess in advance.

---

## Cost snapshot (directional, confirm current rates before relying on them)

| Provider            | Per-OTP cost (India)                                      | Free tier                                                          | Notes                                                                       |
| ------------------- | --------------------------------------------------------- | ------------------------------------------------------------------ | --------------------------------------------------------------------------- |
| **MSG91** (chosen)  | ~₹0.20–0.25 (~$0.0024–0.003)                              | No unconditional free tier; ask about startup credits at signup    | Best India delivery, DLT-native, used by Razorpay/Zomato/Swiggy at scale    |
| Firebase Phone Auth | $0.01/verification (India)                                | 10 SMS/day, test numbers only — not usable in production at volume | Easiest to wire up, but ~4x MSG91's per-verification cost for India traffic |
| Twilio Verify       | ~$0.05/verification + carrier fees                        | Small trial credit (~$15), no ongoing free tier                    | Best global reach — earmarked as the later provider for non-Indian numbers  |
| 2Factor.in          | Comparable to MSG91, SLA-based (refunds undelivered OTPs) | Free trial credits at signup                                       | Reasonable second India quote to compare against MSG91                      |

Because this design only sends an OTP at signup and at password reset (not per
login), even the higher-cost providers stay cheap in absolute terms at pre-launch
scale — the provider choice matters more for reliability and DLT-compliance
friction than for raw per-message price.

# Recommendation Algorithm Options — Reference Notes (DRAFT — revisit once event pipeline has real data)

> Sequencing note: none of this is worth wiring up yet. A recommender is only as good as the interaction data behind it — plugging any of these in before the event pipeline (see `analytics-tracking-plan.md`) has real signal flowing will just produce popularity-only results regardless of algorithm. This doc is here so the research doesn't have to be redone later.

## Top pick given this stack: Gorse

- **What it is:** a complete, self-hosted, open-source recommender system (Go, Apache 2.0 license). Not just an algorithm library — a full service. You feed it users, items, and interaction "feedback"; it automatically trains models in the background and exposes a REST API to fetch ranked recommendations per user.
- **Why it fits particularly well here:** it natively supports **MongoDB and Redis as storage** — the same two databases already running in this project. No new infrastructure category needed, just another service alongside the existing ones.
- **Features worth knowing about:**
  - Multi-source recommendations: popularity, latest, user-to-user, item-to-item, and collaborative filtering, combined
  - AutoML-style model search — tries several algorithms against your actual feedback data and picks what performs best, which matters for the "tweak later once real usage data exists" goal
  - Cold-start handling built in (falls back to popularity/latest for new users with no history) — relevant for a fresh launch with initially-sparse data
  - GUI dashboard for monitoring, data management, and recommendation-pipeline inspection
  - Supports multimodal content embeddings (text/image/video) and both classical and LLM-based rankers, for later if wanted
  - Playground/docker mode for quick local trial: `docker run -p 8088:8088 zhenghaoz/gorse-in-one --playground`
- **How it plugs into this codebase (conceptually):** Gorse runs as its own service, not inside the Node backend. Flow: the event pipeline sends "user X interacted with item Y" as feedback into Gorse via its API → Gorse trains in the background → the Node backend calls Gorse's recommend endpoint for a ranked list of item IDs → those IDs get hydrated against the existing `Video`/`Short` collections to render the actual feed. It's a bolt-on sitting alongside the system, not a rewrite of anything existing.
- Links: https://gorse.io · https://github.com/gorse-io/gorse

## Alternative: run it yourself in Python (no extra long-running service)

If a separate Go service isn't wanted, these are periodic-batch-job options instead of a served system — a scheduled job reads from Mongo, trains, and writes ranked results back into Mongo/Redis for the Node app to read directly (no live inference call, more manual wiring, no dashboard/ops tooling included):

- **`implicit`** — fast Python implementations of algorithms (ALS, BPR) built specifically for _implicit feedback_ data — i.e. watches/clicks/dwell-time, not explicit star ratings. This matches the shape of the data this project is already collecting closely.
- **`LightFM`** — hybrid recommender combining content-based and collaborative filtering in one model; generally a stronger cold-start story since it can use item metadata (tags/category) alongside interaction data, not just interactions alone.
- **RecBole** — a broader research-oriented library implementing a large catalog of recommendation algorithms, useful if experimenting with several approaches side by side later.

## Not recommended for this use case

- **Apache PredictionIO** — older, Spark-based; largely inactive compared to the above.
- Commercial SaaS options (Recombee, Google Recommendations AI, Rumo, Froomle, etc.) — capable, but the ask here was specifically self-hosted/open-source to own and tweak directly, so these weren't pursued further.

## Decision when this gets picked back up

Two real paths, not mutually exclusive to explore:

1. **Gorse** — faster to stand up, less custom code, comes with monitoring/dashboard, costs one more deployed service.
2. **Python (`implicit` / `LightFM`) batch job** — more control and no extra always-on service, but more integration work and no built-in tooling.

Revisit once the event pipeline (`analytics-tracking-plan.md`) has been live long enough to produce a meaningful trickle of real interaction data.

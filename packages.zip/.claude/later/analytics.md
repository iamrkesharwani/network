# User Behavior Tracking / Analytics Pipeline — Checkpoint Plan (DRAFT — more brainstorming pending)

> This is a checkpoint of decisions made so far, not a finished spec. Event taxonomy detail, entity scope, and a few other things are still open — pick this back up next session before writing code.

## 0. What this is actually for

Two distinct things, don't conflate them:

1. **Event logging** — recording raw facts about what users do (clicked, scrolled past, watched, searched). Build this now.
2. **Signal/feature extraction** — turning that raw log into something a recommender can use (e.g. "this user favors cooking content"). This happens later, via periodic jobs that read the log — not live, not now. Building this prematurely, before there's real usage data to validate against, tends to get thrown away.

Scope for right now is **#1 only**: log everything worth logging, cheaply and reliably, in a shape that survives into whatever the recommendation system ends up needing.

## 1. Decisions locked in so far

- **v1 event scope: everything at once** — watch behavior, clicks, scroll/dwell, search, social actions (like/comment/share/save/follow) all go in from day one.
- **No hard delete, ever, on raw data.** Retention is handled by archiving to a colder, less-indexed collection, not by TTL-deleting anything. See §3.
- **Scroll/feed dwell time is captured via client-side pre-aggregation** (Intersection Observer), not raw scroll-position sampling. See §2.
- **No Redis/BullMQ buffering on the ingestion path.** That pattern (used for watch-progress) exists to collapse repeated overwrites of the same key into one write — it doesn't apply here, since these are distinct append-only records, not "latest value" updates. The actual volume lever is client-side batching before the request is even sent.

## 2. Ingestion design

**Client side:**

- A generic in-memory event buffer (`track(eventType, entityType, entityId, metadata)`) that any part of the app can push into — click handlers, like/comment/share/follow actions, search bar, etc.
- **Feed items specifically** use an Intersection-Observer-based hook instead of calling `track()` directly on every interaction: it watches when an item enters/exits the viewport, computes dwell time locally, and pushes **one** compact event per item ("shown 1.2s, scrolled past" / "shown 4.5s, clicked") — not a stream of scroll samples.
- The buffer flushes as a single batched request every ~10s, and also on page-hide/unmount as a failsafe (same idea as the existing player-telemetry tick-on-unmount pattern already in this codebase).

**Server side:**

- One generic ingestion endpoint receives a batch (array of events) and does a single bulk insert into the `events` collection. No per-event round trip, no Redis hop — the client-side batching already did the volume-reduction work.
- Kept deliberately simple/generic (`eventType` + `entityType` + `entityId` + freeform `metadata`) so adding a new event type later is just a new string, not a new module.

## 3. Storage & retention

Two collections, not one:

|          | `events` (hot)                                           | `events_archive` (cold)                    |
| -------- | -------------------------------------------------------- | ------------------------------------------ |
| Holds    | Recent window (e.g. last ~90 days)                       | Everything older than that                 |
| Indexing | Normal — fast to query                                   | Minimal — just enough to write to it       |
| Purpose  | Recent-data queries, debugging, early rollup experiments | Long-term safety net, nothing is ever lost |

A scheduled job (same BullMQ-based scheduling pattern already used elsewhere in this codebase) periodically moves aging documents from `events` into `events_archive` — it **moves**, it never deletes. This removes the "I'll lose data if I miss a deadline" risk entirely: being late just means the archive collection grows larger than planned, which costs a bit of cheap storage, not your signal. Whenever the rollup/recommendation-feature work actually happens, it processes both collections — nothing has to be rescued from an expired TTL.

## 4. Open items to brainstorm next session

- Full event taxonomy: exact list of `eventType` values across watch / click / scroll / search / social, and what `metadata` shape each one needs.
- Entity types covered (video, short, post, comment, user, search query, etc.) and how `entityId` resolves per type.
- Whether to log events for anonymous/pre-login visitors (sessionId-only) or authenticated users only.
- Where the hot→archive move job lives (likely its own small module, e.g. `analytics/analytics.archive.worker.ts`) and exact hot-window length (90 days was a starting suggestion, not locked in).
- Any admin/internal read access needed on the raw log before rollups exist (e.g. a basic internal query tool), or whether it's purely write-only until the rollup phase.

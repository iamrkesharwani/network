> Made in India, built for the world. India-first features are a differentiator, not a
> restriction. English and international users are first-class throughout.

## Phase 0 - Foundation

> Infrastructure only. Nothing domain-specific.

- [x] Monorepo root with npm workspaces
- [x] `@network/shared`, `@network/client`, `@network/server` initialised
- [x] TypeScript configured per package
- [x] Vite alias for `@network/shared` resolving from source
- [x] `tsx watch` dev runner on server

**Shared**

- [x] Zod schemas: auth, user, video, short, post, comment, playlist, message, search
- [x] Types: all domain interfaces including E2EE message shape
- [x] Constants: one file per domain, no magic values (see `CLAUDE.md`)
- [x] Utils: `formatDuration`, `formatCount`, `formatDate`, `validators`
- [x] Barrel `index.ts`

**Server**

- [x] Express app with CORS, helmet, sanitize, body parser
- [x] HTTP server with graceful shutdown
- [x] Mongoose connection with event listeners
- [x] Pino logger
- [x] Zod env validation
- [x] ioredis client with pub/sub export
- [x] Socket.io with Redis adapter and auth handshake
- [x] `ApiError`, `ApiResponse`, `asyncHandler`, `paginate` utils
- [x] Error, validate, auth, rate limit, upload middleware
- [x] Route index mounted at `/api/v1`

**Client**

- [x] Redux store with RTK Query middleware
- [x] Axios instance with interceptors and refresh retry
- [x] Shared hooks: `useAppDispatch`, `useAppSelector`, `useDebounce`, `useIntersectionObserver`, `useSocket`, `useTheme`
- [x] Shared components: `Button`, `Avatar`, `Modal`, `Spinner`, `Toast`, `InfiniteScroll`
- [x] `ProtectedRoute`, `Navbar`, `Sidebar`, `PageWrapper`, `AppRoutes`
- [x] Design system: `theme.css`, dark-first, saffron primary, Space Grotesk + Inter + JetBrains Mono
- [x] `uiSlice`: theme toggle, localStorage persistence

**Self-hosted media pipeline**

- [x] `web.ts` / `worker.ts` process split: API+SSR+Socket.io+light queues vs. media-ingest worker
- [x] Self-hosted ffmpeg transcode provider: single-pass H.264/AAC MP4, `faststart` for seeking
- [x] Multi-stage Dockerfile, `ffmpeg` baked into the runtime image
- [x] R2 two-bucket delivery: raw uploads (private) and processed media (public, CDN-served)
- [x] Raw-upload cleanup after transcode succeeds or fails
- [x] Metrics: queue depth, job duration, and failure tracking exposed on `/metrics`
- [x] CI pipeline: typecheck and build on every push and pull request
- [x] Full-monorepo typecheck and production build verified

---

## Phase 1 - MVP + Core Features

> The complete platform surface: content, discovery, and social features. Deployment does not
> begin until this phase is done.

**Auth**

- [x] User model, auth service, controller, routes, validation
- [x] JWT access token + refresh token rotation via Redis, reuse/replay detection
- [x] Argon2 password hashing
- [x] Email OTP verification, password reset via signed token
- [x] Google OAuth via PKCE
- [x] Login, Signup, Verify Email, Forgot/Reset Password pages, OAuth callback handling
- [ ] Phone number + OTP login as a primary method alongside email (see Phase 2, India-first)

**Video**

- [x] Video model, repository, service, controller, routes
- [x] R2 raw upload, worker-side transcode via the self-hosted ffmpeg pipeline
- [x] Thumbnail extraction and image upload
- [x] Video API, video state slice, upload form, edit form, upload page

**Shorts**

- [x] Short model, repository, service, controller, routes
- [x] Short API, short card, upload form, short feed, shorts page

**Post**

- [x] Post model, repository, routes, types; create/edit/delete, upload, and reaper services
- [x] Post API, post card, grid, list, composer, details form, edit form, posts feed page

**Creator dashboard**

- [x] Creator model, repository, controller, routes; badges, milestones, and stats tracking
- [x] Creator profile, publish, and trust services
- [x] Creator API, badge showcase, badge notifications, creator settings page

**Profile**

- [x] Profile header, tab navigation, mobile menu, per-tab content panels
- [x] Visibility filter, profile view mode, profile page

**Playback**

- [ ] Video player with native HTML5 range-request seeking
- [ ] Playback state and keyboard shortcuts
- [ ] Watch page
- [ ] Resume playback via watch history
- [ ] Shorts vertical swipe player: scroll snap and autoplay on scroll

**Feed**

- [x] Feed service, controller, routes - unified video/short/post mixing engine
      (`mix.service.ts`, `FEED_MIX_RATIO`), replacing the old video+post-only
      random interleave. See `.claude/searchandfeed-plan.md`
- [x] Feed API and live per-content-type feed hooks - superseded by
      `FeedRenderer` + `useMixedFeedPools`, one shared engine for Home and
      Search "All"
- [x] Post cards support a multi-image carousel, not just a single image
- [x] Standalone `/posts` nav destination retired - posts now live only inside
      the unified feed and the Search "Posts" tab
- [x] `/` is the literal Home/Feed route (was `/feed` + a redirect)
- [ ] Verify trending and following ranking logic ahead of Phase 6 recommendation work

**Search**

- [x] Search service: MongoDB text index on title/tags (video, short), text
      (post), name/username (user, for creator search)
- [x] Search controller and routes: mixed "All", single-type (video/short/post),
      and creator search, all rate-limited
- [x] Search API, search bar (Navbar, debounced), results page with tabs
- [ ] Cross-script search (see Phase 2, India-first)

**User**

- [x] User repository, model, and profile service
- [x] Avatar upload with resizing
- [ ] Consolidate user-facing endpoints into a single user module ahead of the phone-auth work

**Watch History**

- [ ] Watch history model, repository, service, controller, routes

**Channels & Follow**

- [ ] Follow model, repository, service, controller, routes
- [ ] Channel API, channel banner, channel video grid, follow button, channel page

**Engagement**

- [ ] Like: polymorphic model, toggle, count
- [ ] Comment: threaded, edit, delete, list
- [ ] Share: signed URL, native share API with copy fallback
- [ ] Comment API, comment list, comment item, comment input

**Playlists**

- [ ] Playlist and playlist item models, full CRUD with reorder
- [ ] Playlist API, playlist card, playlist menu, playlist page

**Bookmarks**

- [ ] Bookmark model, full CRUD, bookmark API, bookmark button

**Notifications**

- [ ] Notification model, service with unread count
- [ ] Queue worker: follow, like, comment reply, new video triggers
- [ ] Socket.io emit on new notification
- [ ] Notification API, notification state slice, bell, list, notifications page

**Messaging, End-to-End Encrypted**

- [ ] RSA-OAEP 2048 keypair via SubtleCrypto, public key stored server-side
- [ ] Private key AES-GCM encrypted with a PBKDF2-derived key, stored in IndexedDB
- [ ] Per-message AES-GCM key, ciphertext and encrypted keys per recipient
- [ ] Conversation and message models, service, controller, routes
- [ ] Key manager, message encryption and decryption utilities
- [ ] Message API, message state slice, conversation list, message thread, message input, messages page
- [ ] Key recovery flow for a missing local key

**Curated Content**

- [ ] Admin role enforcement in auth middleware
- [ ] Featured banner sourced from pinned content
- [ ] Trending calculated from recent view volume
- [ ] Home feed updated with banner and curated shelves
- [ ] Trending shelves shaped by festivals, sports, and other curated hot topics

---

## Phase 2 - India-first & Global

> Made in India, built for the world. India-first differentiators, global-usable throughout.

**Identity & access**

- [ ] Phone number + OTP login as the primary auth method, `+91` default country code, international numbers supported
- [ ] Currency field on pricing and payouts, INR default

**Language & input**

- [ ] Multi-language UI: 10 to 15 Indian languages, with English fully first-class
- [ ] Hinglish/Indic transliteration input: Roman script to native script suggestions
- [ ] Cross-script search, for example "diwali" matches "दिवाली"
- [ ] Voice posting and voice search: regional language speech-to-text

**Distribution & growth**

- [ ] WhatsApp-native share cards: branded, watermarked clip and image cards
- [ ] Data Saver mode: low-resolution default, offline save-for-later, adaptive to network type

**Community**

- [ ] Language- and city-based communities and rooms
- [ ] Trending shelves shaped by festivals, sports, and other curated hot topics

**Monetization**

- [ ] UPI-native tipping: deep link and QR, one-time creator tips
- [ ] Card-based payments for international reach
- [ ] Payment provider selection

**Branding**

- [ ] "Made in India" badge and credit: footer, about page, splash

**Later**

- [ ] Gamified engagement: streaks and coins
- [ ] Optional government-ID-based creator verification badge

---

## Phase 3 - Compliance & Trust

**Legal**

- [ ] IT Rules 2021: published grievance officer contact, physical India address, takedown request workflow with SLA tracking
- [ ] Digital Personal Data Protection Act: purpose-specific consent notices, data erasure workflow
- [ ] GDPR readiness, revisited once there is a meaningful EU user base

**Security**

- [x] Password and email length limits enforced
- [x] Session revocation on password change and reset
- [x] Refresh tokens hashed at rest, with reuse and replay detection
- [x] Rate limiting active by default in every environment
- [x] Per-account login lockout and OTP attempt limits
- [x] Account enumeration closed on registration and login
- [x] Content Security Policy and HSTS enforced in production
- [x] Secure-cookie behavior explicitly configured, not environment-inferred
- [x] CSRF exemptions scoped precisely
- [x] Validation limits consistent between client and server schemas
- [x] Proxy trust configuration validated at startup
- [x] OAuth avatar URLs sanitized before storage
- [ ] Constrain client-declared MIME type and size on presigned video uploads at the storage-policy level
- [ ] Confirm webhook replay protection remains necessary under the current media provider

---

## Phase 4 - Deploy

> Blocked until Phase 1 and Phase 2 are complete. Standing rule: fixed-cost or free infrastructure
> only, never usage-billed or metered. Manual deployment is acceptable; unpredictable billing is
> not.

- [x] Hosting decision: Oracle Cloud Infrastructure, Always Free tier
- [ ] Provision two compute instances (`web`, `worker`) in an Indian OCI region
- [ ] Configure a budget alert as a billing backstop
- [ ] Point DNS at the `web` instance
- [ ] Write deployment scripts and documentation against the provisioned infrastructure
- [ ] Cancel the legacy paid video-hosting subscription
- [ ] End-to-end pipeline verification: upload, transcode, and playback across all content types
- [ ] Worker load test to establish real per-instance capacity

---

## Phase 5 - Scalability

- [ ] Mongoose schema indexes on all hot query fields
- [ ] Cache service wrapping Redis, applied to feeds, view counts, tokens
- [ ] Secondary-preferred read routing on feed and search queries
- [ ] Lean queries on all read-heavy paths
- [ ] Cursor-based pagination
- [ ] Additional queue definitions: feed, notification
- [ ] Fan-out-on-write feed with a fan-out-on-read fallback for large accounts
- [ ] Cluster mode in production
- [ ] Health check covering database and cache connectivity on the web process
- [ ] Metrics dashboard
- [ ] Error tracking initialised in production
- [ ] Database slow-query monitoring

---

## Phase 6 - Advanced Features

**Recommendations**

- [ ] Feed recommendations from watch history
- [ ] Engagement-weighted short-form ranking
- [ ] "More like this" and continue-watching rows
- [ ] Cold-start onboarding interest picker

**Search**

- [ ] Full-text search index with autocomplete
- [ ] Advanced filters: category, duration, date, format
- [ ] Hashtag pages, recency-weighted ranking

**Creator Tools**

- [ ] Video analytics: views by day, watch time, like ratio, audience region and device
- [ ] Chapter markers from description timestamps
- [ ] Scheduled publishing
- [ ] Collaborator tags on video
- [ ] Auto-generated captions via speech-to-text transcription

**Live**

- [ ] Live streaming with a per-creator stream key
- [ ] Live chat and pinned messages
- [ ] Real-time viewer count
- [ ] VOD save on broadcast end
- [ ] Paid message highlighting

**Monetization**

- [ ] Ad slot placeholders: pre-roll, mid-roll
- [ ] Creator fund eligibility
- [ ] Live tipping
- [ ] Brand partnership page

**Admin**

- [ ] Platform statistics, content flagging, user suspension, role management
- [ ] Content moderation queue, curated collections management

---

## Phase 7 - Launch Hardening

- [ ] Language detection, RTL support, region-based feeds
- [ ] Web application firewall rules
- [ ] HTML sanitization on comment and bio fields
- [x] Decision: no signed or expiring playback URLs for private or unlisted content, by design
- [ ] Automated content-safety scanning on the ingest pipeline
- [ ] Lazy loading on all feed cards
- [ ] Edge caching tuned for processed media assets
- [ ] Full deployment step added to CI/CD
- [ ] Staging environment gates production releases
- [ ] Multi-region rollout: India, Southeast Asia, Europe, North America
- [ ] README: setup, architecture, encryption design, deployment guide

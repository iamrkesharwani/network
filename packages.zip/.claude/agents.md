network - project conventions

- Monorepo: packages/client (React/Vite/Redux), packages/server (Express/Mongoose/BullMQ), packages/shared (types, zod schemas, constants, formatters - consumed by both via the @network/shared package alias, resolved through path mappings in each tsconfig.json, not a build step)

- Folder structure is strictly feature-based
  - Files organized by feature, never by generic type-buckets (no top-level components/, hooks/, utils/ that mix unrelated features together)
  - Each feature owns everything it needs - components, hooks, pages, api slice, skeleton states - inside its own folder
  - Client (packages/client/src/)
    - app/ - bootstrap only: App.tsx, entry-client.tsx, entry-server.tsx, routes/, store/, layout/ (Navbar/Sidebar/PageWrapper - app-shell chrome, not a feature)
    - features/<name>/ - one folder per feature (auth, feed, post, short, video, upload, creator, ui). Inside: components/, hooks/, pages/, form/, skeleton/, utils/ as needed, plus the feature's API slice / Redux slice at the top level of the folder
    - shared/ - only truly feature-agnostic, reusable-by-anything code: ui-kit/ (design-system primitives: Button, Modal, Toast, Avatar, generic Skeleton), hooks/ (useDebounce, useAppSelector, etc - not tied to one feature), lib/ (axios/http plumbing), utils/cn.ts. If something is specific to one feature (a skeleton, a grid util, a persistence helper), it belongs in that feature's folder, not here
  - Server (packages/server/src/)
    - modules/<name>/ - one folder per domain module (auth, post, short, video, upload, creator, webhook, user, email). Each owns its routes/controllers/services/repository/model
    - core/ - genuine cross-cutting infrastructure used by 3+ modules: config/, env/, middleware/, providers/ (storage/video/image 3rd-party integrations), types/, utils/ (ApiError, logger, etc). This is infra, not a feature - don't add feature-specific code here
  - Before adding a new top-level folder, ask: is this owned by one feature (put it inside that feature), or is it real cross-cutting infrastructure used by many (shared/ or core/)? Never create a folder that buckets by type across features (e.g. a top-level skeleton/ holding every feature's skeleton - that was the exact anti-pattern this repo was restructured out of)

- Constants: all live in packages/shared/src/constants, never inline
  - No magic strings/numbers, cookie names, socket event names, queue names, TTLs, durations, route paths, or storage keys should be hardcoded in client or server source
  - They belong in packages/shared/src/constants/<domain>.constants.ts, exported through packages/shared/src/index.ts, imported via @network/shared from wherever they're needed
  - One file per domain: auth.constants.ts, media.constants.ts, time.constants.ts, upload.constants.ts, video.constants.ts, short.constants.ts, user.constants.ts, general.constants.ts, routes.constants.ts (client route paths, as CLIENT_ROUTES.X), storage.constants.ts (localStorage keys), etc
  - If the same literal value shows up in more than one file (even expressed differently, e.g. 5 \* 60 vs 300), it's a signal to extract it - that kind of drift is exactly what caused real bugs before (Mongoose maxlength vs Zod .max() on title/description getting out of sync)
  - Cross-file references within shared/src use relative imports with explicit .js extensions (NodeNext convention) - e.g. auth.constants.ts imports FIFTEEN_MINUTES_SECONDS from ./time.constants.js
  - New constants files must be added to the export \* from './constants/X.constants.js' list in packages/shared/src/index.ts or they won't be reachable via @network/shared

- Import conventions (don't get these backwards)
  - Server (packages/server): moduleResolution is nodenext. All relative imports need an explicit .js extension even though the source is .ts (e.g. import { logger } from '../core/utils/logger.js')
  - Client (packages/client): moduleResolution is bundler (Vite). Relative imports have no extension (e.g. import Button from '../../shared/ui-kit/Button')
  - Don't copy one package's import style into the other

- Workflow expectations for structural changes
  - Large refactors (file moves, mass import fixes) are expected to be executed directly, not just proposed as a diagram - but a proposal should be shown and approved first for anything as big as a folder restructure
  - After any structural change, verify with tsc --noEmit in all three packages (client, server, shared) plus a real vite build (client + SSR) - not just "no errors in the file I touched"
  - When comparing "did I break something" vs "was this already broken," use git stash to diff typecheck output against the pre-change state rather than guessing
  - Use git mv for file relocations (preserves history) and prefer a scripted codemod (resolve old-path to new-path per moved file, rewrite relative specifiers) over hand-fixing imports one by one when more than a handful of files move
  - Don't leave half-finished/placeholder UI (e.g. a hardcoded "Coming soon" tile) sitting next to a fully-wired backend field - if the data exists end-to-end, wire it up rather than stubbing it

- Diagram requests
  - When asked for an ASCII folder-structure diagram "to work from locally" - that means text only, "without comments," strip all inline annotations/arrows/notes and expand every file individually (no {A,B,C}.ext grouping shorthand)

- No comments
  - When making code changes, it is strictly prohibited to not add any comments, instead write the code in such a manner that the code is self explanatory

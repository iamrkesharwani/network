import type { PaginatedResponse } from '@network/shared';
import { VideoModel, type IVideoDocument } from './video.model.js';
import type { UpdateVideoData, WebhookUpdateData } from './video.types.js';
import mongoose from 'mongoose';
import { paginateQuery } from '../../utils/paginate.js';

export const createPlaceholder = (
  userId: string,
  title: string
): Promise<IVideoDocument> =>
  VideoModel.create({
    userId: new mongoose.Types.ObjectId(userId),
    title,
  });

export const findById = (id: string): Promise<IVideoDocument | null> =>
  VideoModel.findById(id).populate('userId', 'username avatarUrl').exec();

export const findByIdWithStorageKey = (
  id: string
): Promise<IVideoDocument | null> =>
  VideoModel.findById(id).select('+storageKey').exec();

export const findByProviderVideoId = (
  providerVideoId: string
): Promise<IVideoDocument | null> =>
  VideoModel.findOne({ providerVideoId }).exec();

export const findPublicFeed = async (
  page: number,
  limit: number
): Promise<Omit<PaginatedResponse<IVideoDocument>, 'success' | 'message'>> => {
  const result = await paginateQuery(
    VideoModel,
    { status: 'READY', visibility: 'public' },
    { createdAt: -1 },
    page,
    limit
  );

  await VideoModel.populate(result.data, {
    path: 'userId',
    select: 'username avatarUrl',
  });

  return result;
};

export const findByUserId = async (
  userId: string,
  page: number,
  limit: number
): Promise<Omit<PaginatedResponse<IVideoDocument>, 'success' | 'message'>> => {
  const result = await paginateQuery(
    VideoModel,
    { userId: new mongoose.Types.ObjectId(userId) },
    { createdAt: -1 },
    page,
    limit
  );

  await VideoModel.populate(result.data, {
    path: 'userId',
    select: 'username avatarUrl',
  });

  return result;
};

export const updateById = (
  id: string,
  data: UpdateVideoData
): Promise<IVideoDocument | null> =>
  VideoModel.findByIdAndUpdate(id, data, {
    new: true,
    runValidators: true,
  }).exec();

export const updateByProviderVideoId = (
  providerVideoId: string,
  data: WebhookUpdateData
): Promise<IVideoDocument | null> =>
  VideoModel.findOneAndUpdate({ providerVideoId }, data, {
    new: true,
    runValidators: true,
  }).exec();

export const incrementViews = (id: string): Promise<unknown> =>
  VideoModel.updateOne({ _id: id }, { $inc: { views: 1 } }).exec();

export const deleteById = (id: string): Promise<IVideoDocument | null> =>
  VideoModel.findByIdAndDelete(id).select('+storageKey').exec();

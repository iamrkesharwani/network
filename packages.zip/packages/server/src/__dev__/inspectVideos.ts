import { connectDb } from '../core/config/db.js';
import { VideoModel } from '../modules/video/video.model.js';
import mongoose from 'mongoose';

await connectDb();

const videos = await VideoModel.find({})
  .select('title status visibility category tags deletedAt createdAt')
  .sort({ _id: -1 })
  .limit(30)
  .lean();

console.table(
  videos.map((v) => ({
    title: v.title,
    status: v.status,
    visibility: v.visibility,
    category: v.category,
    tags: v.tags?.join(','),
    deletedAt: v.deletedAt,
  }))
);

await mongoose.disconnect();

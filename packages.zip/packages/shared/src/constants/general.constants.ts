export const SITE_NAME = 'Network';

export const SEVEN_DAYS_MS = 604800000;

import { useEffect, useRef, useState } from 'react';
import { createPortal } from 'react-dom';
import { MoreVertical, Edit2, Trash2, EyeOff, Eye, Flag } from 'lucide-react';
import { cn } from '../../utils/cn';

interface CardOptionsMenuProps {
  itemLabel: string;
  isOwner: boolean;
  onEdit?: (e: React.MouseEvent) => void;
  onDeleteClick?: (e: React.MouseEvent) => void;
  visibilityAction?: {
    label: string;
    toPublic: boolean;
    onClick: (e: React.MouseEvent) => void;
  };
  onReport?: (e: React.MouseEvent) => void;
}

interface MenuPosition {
  top: number;
  right: number;
}

const CardOptionsMenu = ({
  itemLabel,
  isOwner,
  onEdit,
  onDeleteClick,
  visibilityAction,
  onReport,
}: CardOptionsMenuProps) => {
  const [menuOpen, setMenuOpen] = useState(false);
  const [position, setPosition] = useState<MenuPosition | null>(null);
  const buttonRef = useRef<HTMLButtonElement>(null);

  const openMenu = () => {
    const rect = buttonRef.current?.getBoundingClientRect();
    if (!rect) return;
    setPosition({
      top: rect.bottom + 4,
      right: window.innerWidth - rect.right,
    });
    setMenuOpen(true);
  };

  const handleToggle = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (menuOpen) {
      setMenuOpen(false);
    } else {
      openMenu();
    }
  };

  useEffect(() => {
    if (!menuOpen) return;
    const close = () => setMenuOpen(false);
    window.addEventListener('scroll', close, true);
    window.addEventListener('resize', close);
    return () => {
      window.removeEventListener('scroll', close, true);
      window.removeEventListener('resize', close);
    };
  }, [menuOpen]);

  const handleEdit = (e: React.MouseEvent) => {
    setMenuOpen(false);
    onEdit?.(e);
  };

  const handleVisibility = (e: React.MouseEvent) => {
    setMenuOpen(false);
    visibilityAction?.onClick(e);
  };

  const handleDelete = (e: React.MouseEvent) => {
    setMenuOpen(false);
    onDeleteClick?.(e);
  };

  const handleReport = (e: React.MouseEvent) => {
    setMenuOpen(false);
    onReport?.(e);
  };

  if (!isOwner && !onReport) return null;

  return (
    <div className="relative shrink-0 self-start">
      <button
        ref={buttonRef}
        type="button"
        onClick={handleToggle}
        aria-label={`${itemLabel} options`}
        aria-expanded={menuOpen}
        className={cn(
          'p-1.5 -mr-1 rounded-lg text-icon transition-all focus:outline-none',
          'opacity-100 md:opacity-0 md:group-hover:opacity-100 focus:opacity-100',
          menuOpen
            ? 'opacity-100 bg-surface-overlay text-icon-hover'
            : 'hover:bg-surface-raised hover:text-icon-hover'
        )}
      >
        <MoreVertical className="w-4 h-4" strokeWidth={1.75} />
      </button>

      {menuOpen &&
        position &&
        createPortal(
          <>
            <div
              className="fixed inset-0 z-40"
              onClick={() => setMenuOpen(false)}
              aria-hidden="true"
            />
            <div
              style={{
                position: 'fixed',
                top: position.top,
                right: position.right,
              }}
              className="z-50 w-40 py-1 rounded-xl bg-surface-overlay border border-border shadow-xl shadow-black/40"
            >
              {isOwner ? (
                <>
                  <button
                    type="button"
                    onClick={handleEdit}
                    className="flex items-center gap-2.5 w-full px-3 py-2 text-sm text-text-secondary hover:text-text-primary hover:bg-surface-raised transition-colors"
                  >
                    <Edit2 className="w-3.5 h-3.5 shrink-0" strokeWidth={1.75} />
                    Edit
                  </button>
                  {visibilityAction && (
                    <button
                      type="button"
                      onClick={handleVisibility}
                      className="flex items-center gap-2.5 w-full px-3 py-2 text-sm text-text-secondary hover:text-text-primary hover:bg-surface-raised transition-colors"
                    >
                      {visibilityAction.toPublic ? (
                        <Eye className="w-3.5 h-3.5 shrink-0" strokeWidth={1.75} />
                      ) : (
                        <EyeOff className="w-3.5 h-3.5 shrink-0" strokeWidth={1.75} />
                      )}
                      {visibilityAction.label}
                    </button>
                  )}
                  <button
                    type="button"
                    onClick={handleDelete}
                    className="flex items-center gap-2.5 w-full px-3 py-2 text-sm text-error hover:bg-error-subtle transition-colors"
                  >
                    <Trash2 className="w-3.5 h-3.5 shrink-0" strokeWidth={1.75} />
                    Delete
                  </button>
                </>
              ) : (
                onReport && (
                  <button
                    type="button"
                    onClick={handleReport}
                    className="flex items-center gap-2.5 w-full px-3 py-2 text-sm text-text-secondary hover:text-text-primary hover:bg-surface-raised transition-colors"
                  >
                    <Flag className="w-3.5 h-3.5 shrink-0" strokeWidth={1.75} />
                    Report
                  </button>
                )
              )}
            </div>
          </>,
          document.body
        )}
    </div>
  );
};

export default CardOptionsMenu;

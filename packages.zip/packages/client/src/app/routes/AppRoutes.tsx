import { type RouteObject } from 'react-router-dom';
import { CLIENT_ROUTES } from '@network/shared';
import AppInitGate from './AppInitGate';
import RequireAuth from './RequireAuth';
import PageWrapper from '../layout/PageWrapper';
import MobileAppShell from '../layout/MobileAppShell';
import Login from '../../features/auth/pages/Login';
import Register from '../../features/auth/pages/Register';
import VerifyEmail from '../../features/auth/pages/VerifyEmail';
import GuestRoute from './GuestRoute';
import ForgotPassword from '../../features/auth/pages/ForgotPassword';
import ResetPassword from '../../features/auth/pages/ResetPassword';
import OAuthCallback from '../../features/auth/pages/OAuthCallback';
import Feed from '../../features/feed/Feed';
import VideoWatch from '../../features/video/pages/VideoWatch';
import ShortsEntry from '../../features/short/pages/ShortsEntry';
import ShortWatch from '../../features/short/pages/ShortWatch';
import MessagesPlaceholder from '../../features/message/pages/MessagesPlaceholder';
import UploadHub from '../../features/upload/components/UploadHub';
import VideoUploadWizard from '../../features/video/form/VideoUploadWizard';
import ShortUploadWizard from '../../features/short/form/ShortUploadWizard';
import PostComposer from '../../features/post/form/PostComposer';
import PostsFeedPage from '../../features/post/pages/PostsFeedPage';
import ProfilePage from '../../features/profile/pages/ProfilePage';
import SettingsPage from '../../features/settings/pages/SettingsPage';
import SearchResultsPage from '../../features/search/pages/SearchResultsPage';
import JuryQueuePage from '../../features/jury/pages/JuryQueuePage';
import JuryCaseDetailPage from '../../features/jury/pages/JuryCaseDetailPage';
import AppealsPage from '../../features/jury/pages/AppealsPage';
import NotFound from './NotFound';

export const routes: RouteObject[] = [
  { path: CLIENT_ROUTES.OAUTH_CALLBACK, element: <OAuthCallback /> },
  {
    element: <GuestRoute />,
    children: [
      { path: CLIENT_ROUTES.LOGIN, element: <Login /> },
      { path: CLIENT_ROUTES.REGISTER, element: <Register /> },
      { path: CLIENT_ROUTES.VERIFY_EMAIL, element: <VerifyEmail /> },
      { path: CLIENT_ROUTES.FORGOT_PASSWORD, element: <ForgotPassword /> },
      { path: CLIENT_ROUTES.RESET_PASSWORD, element: <ResetPassword /> },
    ],
  },
  {
    element: <AppInitGate />,
    children: [
      {
        element: <MobileAppShell />,
        children: [
          { path: CLIENT_ROUTES.SHORTS, element: <ShortsEntry /> },
          { path: CLIENT_ROUTES.SHORT_WATCH, element: <ShortWatch /> },
          {
            element: <PageWrapper />,
            children: [
              { path: CLIENT_ROUTES.FEED, element: <Feed /> },
              { path: CLIENT_ROUTES.VIDEO_WATCH, element: <VideoWatch /> },
              { path: CLIENT_ROUTES.SEARCH, element: <SearchResultsPage /> },
              { path: CLIENT_ROUTES.POSTS, element: <PostsFeedPage /> },
              { path: CLIENT_ROUTES.POST_WATCH, element: <PostsFeedPage /> },
              { path: CLIENT_ROUTES.PROFILE, element: <ProfilePage /> },
              { path: CLIENT_ROUTES.PROFILE_VIDEOS, element: <ProfilePage /> },
              { path: CLIENT_ROUTES.PROFILE_SHORTS, element: <ProfilePage /> },
              { path: CLIENT_ROUTES.PROFILE_POSTS, element: <ProfilePage /> },
              { path: CLIENT_ROUTES.PROFILE_STATS, element: <ProfilePage /> },
              { path: CLIENT_ROUTES.PROFILE_HISTORY, element: <ProfilePage /> },
              {
                element: <RequireAuth />,
                children: [
                  { path: CLIENT_ROUTES.UPLOAD, element: <UploadHub /> },
                  {
                    path: CLIENT_ROUTES.UPLOAD_VIDEO,
                    element: <VideoUploadWizard />,
                  },
                  {
                    path: CLIENT_ROUTES.UPLOAD_VIDEO_FINALIZE,
                    element: <VideoUploadWizard />,
                  },
                  {
                    path: CLIENT_ROUTES.UPLOAD_SHORT,
                    element: <ShortUploadWizard />,
                  },
                  {
                    path: CLIENT_ROUTES.UPLOAD_SHORT_FINALIZE,
                    element: <ShortUploadWizard />,
                  },
                  {
                    path: CLIENT_ROUTES.UPLOAD_POST,
                    element: <PostComposer />,
                  },
                  {
                    path: CLIENT_ROUTES.UPLOAD_POST_FINALIZE,
                    element: <PostComposer />,
                  },
                  { path: CLIENT_ROUTES.SETTINGS, element: <SettingsPage /> },
                  {
                    path: CLIENT_ROUTES.SETTINGS_MY_INFO,
                    element: <SettingsPage />,
                  },
                  {
                    path: CLIENT_ROUTES.SETTINGS_MY_INFO_BASIC,
                    element: <SettingsPage />,
                  },
                  {
                    path: CLIENT_ROUTES.SETTINGS_MY_INFO_PERSONAL,
                    element: <SettingsPage />,
                  },
                  {
                    path: CLIENT_ROUTES.SETTINGS_MY_INFO_CONTACT,
                    element: <SettingsPage />,
                  },
                  {
                    path: CLIENT_ROUTES.SETTINGS_PREFERENCES,
                    element: <SettingsPage />,
                  },
                  {
                    path: CLIENT_ROUTES.SETTINGS_SECURITY,
                    element: <SettingsPage />,
                  },
                  {
                    path: CLIENT_ROUTES.SETTINGS_ACCOUNT,
                    element: <SettingsPage />,
                  },
                  {
                    path: CLIENT_ROUTES.MESSAGES,
                    element: <MessagesPlaceholder />,
                  },
                  {
                    path: CLIENT_ROUTES.JURY_QUEUE,
                    element: <JuryQueuePage />,
                  },
                  {
                    path: CLIENT_ROUTES.JURY_APPEALS,
                    element: <AppealsPage />,
                  },
                  {
                    path: CLIENT_ROUTES.JURY_CASE,
                    element: <JuryCaseDetailPage />,
                  },
                ],
              },
            ],
          },
        ],
      },
    ],
  },
  { path: '*', element: <NotFound /> },
];

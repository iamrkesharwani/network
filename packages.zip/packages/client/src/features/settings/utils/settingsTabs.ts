import { UserRound, SlidersHorizontal, ShieldCheck, UserCog } from 'lucide-react';
import { CLIENT_ROUTES } from '@network/shared';

export type SettingsTab = 'my-info' | 'preferences' | 'privacy' | 'account';

export interface SettingsTabDef {
  id: SettingsTab;
  label: string;
  icon: typeof UserRound;
  path: string;
}

export const SETTINGS_TABS: SettingsTabDef[] = [
  {
    id: 'my-info',
    label: 'My Info',
    icon: UserRound,
    path: CLIENT_ROUTES.SETTINGS_MY_INFO,
  },
  {
    id: 'preferences',
    label: 'Preferences',
    icon: SlidersHorizontal,
    path: CLIENT_ROUTES.SETTINGS_PREFERENCES,
  },
  {
    id: 'privacy',
    label: 'Privacy',
    icon: ShieldCheck,
    path: CLIENT_ROUTES.SETTINGS_PRIVACY,
  },
  {
    id: 'account',
    label: 'Account',
    icon: UserCog,
    path: CLIENT_ROUTES.SETTINGS_ACCOUNT,
  },
];

export const getActiveSettingsTab = (pathname: string): SettingsTab | null => {
  if (pathname.endsWith('/preferences')) return 'preferences';
  if (pathname.endsWith('/privacy')) return 'privacy';
  if (pathname.endsWith('/account')) return 'account';
  if (pathname.includes('/my-info')) return 'my-info';
  return null;
};

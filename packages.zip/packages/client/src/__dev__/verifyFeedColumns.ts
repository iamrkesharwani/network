import { MOBILE_MAX, TABLET_MAX } from '@network/shared';
import { computeFeedColumns } from '../features/feed/hooks/useFeedColumns';

const assertions: [string, boolean][] = [
  // Mobile portrait: width < MOBILE_MAX, width < height
  [
    'mobile portrait -> 1 col, edge, first 2/regular 4 videos, 2 shorts per block',
    (() => {
      const r = computeFeedColumns(MOBILE_MAX - 1, 900, false);
      return (
        r.columns === 1 &&
        r.widthMode === 'edge' &&
        !r.showChatRail &&
        r.firstVideoBlockSize === 2 &&
        r.videosPerBlock === 4 &&
        r.shortsPerBlock === 2
      );
    })(),
  ],

  // Mobile landscape: width < MOBILE_MAX, width >= height
  [
    'mobile landscape -> 2 col, full, first 4/regular 6 videos, 4 shorts per block',
    (() => {
      const r = computeFeedColumns(MOBILE_MAX - 1, 400, false);
      return (
        r.columns === 2 &&
        r.widthMode === 'full' &&
        !r.showChatRail &&
        r.firstVideoBlockSize === 4 &&
        r.videosPerBlock === 6 &&
        r.shortsPerBlock === 4
      );
    })(),
  ],
  [
    'mobile landscape, exact square counts as landscape (width >= height)',
    (() => {
      const r = computeFeedColumns(MOBILE_MAX - 1, MOBILE_MAX - 1, false);
      return r.columns === 2 && r.widthMode === 'full';
    })(),
  ],

  // Tablet: MOBILE_MAX <= width < TABLET_MAX, orientation-aware
  [
    'tablet portrait -> 2 col, full, first 4/regular 6 videos, 4 shorts per block',
    (() => {
      const r = computeFeedColumns(MOBILE_MAX, 1400, false);
      return (
        r.columns === 2 &&
        r.widthMode === 'full' &&
        !r.showChatRail &&
        r.firstVideoBlockSize === 4 &&
        r.videosPerBlock === 6 &&
        r.shortsPerBlock === 4
      );
    })(),
  ],
  [
    'tablet landscape -> 3 col, full, first 3/regular 6 videos, 5 shorts per block',
    (() => {
      const r = computeFeedColumns(TABLET_MAX - 1, 800, false);
      return (
        r.columns === 3 &&
        r.widthMode === 'full' &&
        !r.showChatRail &&
        r.firstVideoBlockSize === 3 &&
        r.videosPerBlock === 6 &&
        r.shortsPerBlock === 5
      );
    })(),
  ],

  // Desktop: width >= TABLET_MAX, chat-aware
  [
    'desktop, chat closed -> 3 col, no chat rail, first 3/regular 6 videos, 5 shorts per block',
    (() => {
      const r = computeFeedColumns(TABLET_MAX, 900, false);
      return (
        r.columns === 3 &&
        r.widthMode === 'full' &&
        !r.showChatRail &&
        r.firstVideoBlockSize === 3 &&
        r.videosPerBlock === 6 &&
        r.shortsPerBlock === 5
      );
    })(),
  ],
  [
    'desktop, chat open -> 2 col, chat rail shown, first 3/regular 6 videos, 5 shorts per block',
    (() => {
      const r = computeFeedColumns(TABLET_MAX, 900, true);
      return (
        r.columns === 2 &&
        r.widthMode === 'full' &&
        r.showChatRail &&
        r.firstVideoBlockSize === 3 &&
        r.videosPerBlock === 6 &&
        r.shortsPerBlock === 5
      );
    })(),
  ],
  [
    'ultrawide desktop, chat closed -> still 3 col (uncapped, not more columns)',
    (() => {
      const r = computeFeedColumns(3000, 1200, false);
      return r.columns === 3 && r.widthMode === 'full' && !r.showChatRail;
    })(),
  ],
];

let allPassed = true;
for (const [label, passed] of assertions) {
  console.log(`${passed ? 'PASS' : 'FAIL'} — ${label}`);
  if (!passed) allPassed = false;
}

if (!allPassed) {
  throw new Error('Some assertions failed.');
}

console.log('\nAll assertions passed.');
